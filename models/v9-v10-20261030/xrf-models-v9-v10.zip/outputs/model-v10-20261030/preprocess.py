"""Single count-only representation shared by dataset extraction and inference."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import pathlib,sys,importlib.util,functools
import numpy as np
H=pathlib.Path(__file__).resolve().parent;R=H.parents[1];V=R/'outputs/model-v9-20261028'
spec=importlib.util.spec_from_file_location('frozen_global_axis_method',H/'axis_method.py');axis=importlib.util.module_from_spec(spec);spec.loader.exec_module(axis)
axis.dictionary=functools.lru_cache(maxsize=1)(axis.dictionary)
sys.path.insert(0,str(V/'bundle'));import runtime_v6 as base
spectral=sys.modules[base.old.fit_one.__module__]
@functools.lru_cache(maxsize=1)
def dictionary():return spectral.load()

def cost_fit(c,gain,zero):
    d=dictionary();y=np.asarray(c,float).reshape(1024,2).sum(1);best=None
    for h in d['roots']:
        p=d['profiles'][h];theta=np.array([(gain/p['gain_keV_channel']-1)/.01,(zero-p['zero_keV'])/.05,0.]);a=spectral.warped(d[f'design_{h}'],theta,p['gain_keV_channel']);a[:,a.sum(0)<=1e-12]=0;co=axis.safe_irls(a,y,iterations=2);dev=spectral.deviance(y,a@co)
        if best is None or dev<best['deviance']:best=dict(deviance=dev,h=h,theta=theta,a=a,co=co,gain=gain,zero=zero)
    return best

def details(c,best):
    d=dictionary();h=best['h'];a=best['a'];co=best['co'];y=np.asarray(c,float).reshape(1024,2).sum(1);owners=d[f'owners_{h}'];groups=d[f'groups_{h}'];mu=a@co;w=1/np.sqrt(np.maximum(mu,1));aw=a*w[:,None];scale=np.maximum(np.linalg.norm(aw,axis=0),1e-12);cov=np.linalg.pinv((aw/scale).T@(aw/scale),rcond=1e-12)/np.outer(scale,scale);merge=np.array([owners==j for j in range(32)],float);amp=merge@co;err=np.sqrt(np.maximum(np.diag(merge@cov@merge.T),1e-12));delta=np.zeros(32);shell=np.zeros((32,3))
    for j in range(32):
        selected=owners==j
        for k,s in enumerate('KLM'):shell[j,k]=sum(co[i] for i,g in enumerate(groups) if owners[i]==j and str(g).endswith('_'+s))
        if selected.any() and amp[j]>1e-12:
            null=axis.safe_irls(a[:,~selected],y,iterations=2);delta[j]=spectral.deviance(y,a[:,~selected]@null)-best['deviance']
    p=d['profiles'][h]
    return dict(amplitudes=amp,errors=err,snr=amp/err,null_delta=delta,shell=shell,hypothesis=h,continuum_fraction=float(co[owners<0].sum()/max(y.sum(),1)),deviance=best['deviance'],initial_deviance=best['deviance'],gain_keV_channel=best['gain'],zero_keV=best['zero'],noise_fwhm_eV=p['noise_fwhm_eV'],geometry_theta=best['theta'],geometry_converged=True,geometry_accepted=False,geometry_nfev=0,regime=int(best['gain']<.01))

def extract(counts):
    c=np.asarray(counts,float)
    if c.shape!=(2048,) or not np.isfinite(c).all() or np.any(c<0) or np.any(c!=np.floor(c)) or c.sum()<=0:raise ValueError('2048 nonnegative integer counts required')
    original=spectral.fit_one(c,dictionary());props=axis.proposals(c,original['gain_keV_channel'],original['zero_keV']);fits=[cost_fit(c,p['gain'],p['zero']) for p in props['candidates'][:3]];costs=[original['deviance']]+[f['deviance'] for f in fits];order=np.argsort(costs,kind='stable');chosen=int(order[0]);f=original if chosen==0 else details(c,fits[chosen-1]);ff={k:np.array([v]) for k,v in f.items()};s,e,_=base.representation(c[None,:],ff)
    gain=f['gain_keV_channel'];zero=f['zero_keV'];edges=np.linspace(0,28,129);native=zero+gain*(np.arange(2049)-.5);cum=np.interp(edges,native,np.r_[0,np.cumsum(c)],left=0,right=c.sum());aligned=np.sqrt((np.maximum(np.diff(cum),0)+.375)/(c.sum()+.375*128));coverage=np.clip((np.minimum(edges[1:],native[-1])-np.maximum(edges[:-1],native[0]))/np.diff(edges),0,1)
    p=props['candidates'][0] if props['candidates'] else {};gap=(costs[int(order[1])]-costs[int(order[0])])/max(c.sum(),1) if len(order)>1 else 0.;oldg=original['gain_keV_channel'];oldz=original['zero_keV'];q=np.array([gain,zero,f['noise_fwhm_eV']/100,np.log1p(original['deviance']/1024),np.log1p(f['deviance']/1024),f['deviance']/max(original['deviance'],1),500*(gain-oldg)+zero-oldz,1000*(gain-oldg)+zero-oldz,len(props['candidates'])/5,p.get('nonseed_coverage',0),p.get('score',0)-(props['candidates'][1]['score'] if len(props['candidates'])>1 else 0),np.log1p(max(gap,0)),float(chosen==0),p.get('matched_peaks',0)/12,p.get('K_groups',0)/3,p.get('L_groups',0)/3])
    shared=np.r_[s[0],aligned,coverage,q].astype(np.float32);extra=e[0].astype(np.float32);assert shared.shape==(485,) and extra.shape==(32,6);assert np.isfinite(shared).all() and np.isfinite(extra).all()
    audit=dict(gain=float(gain),zero=float(zero),old_gain=float(oldg),old_zero=float(oldz),chosen=chosen,candidate_count=len(fits),old_deviance=float(original['deviance']),deviance=float(f['deviance']),cost_gap_per_count=float(gap))
    return shared,extra,audit
