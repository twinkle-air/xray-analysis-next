"""V9 frozen baseline: byte-identical predictions to the accepted V6 local candidate."""
import pathlib,sys,json,hashlib
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'bundle/improvement/physics'))
import physics_runtime as impl
def verify():
    for rel,digest in json.loads((HERE/'freeze.json').read_text(encoding='utf-8'))['runtime_sha256'].items():
        with (HERE/rel).open('rb') as f:
            if hashlib.file_digest(f,'sha256').hexdigest()!=digest:raise ValueError('V9 frozen dependency changed: '+rel)
def predict(path):
    verify();out=impl.predict(path);out['version']='V9';out['revision']='baseline';return out
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    with pathlib.Path(a.out).open('x',encoding='utf-8') as f:json.dump(predict(a.input),f,ensure_ascii=False,indent=2,allow_nan=False)
