"""V10: unchanged full classifier+quantifier incremental candidate, named and pinned."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import pathlib,importlib.util,functools,json,hashlib,argparse
import numpy as np
from scipy.special import expit
HERE=pathlib.Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('v10_pinned_preprocessor',HERE/'preprocess.py');preprocess=importlib.util.module_from_spec(sp);sp.loader.exec_module(preprocess)
@functools.lru_cache(maxsize=1)
def verify():
    freeze=json.loads((HERE/'freeze.json').read_text(encoding='utf-8'))
    for name,digest in freeze['local_files'].items():
        with (HERE/name).open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
        if actual!=digest:raise ValueError('V10 local dependency changed: '+name)
    for path,digest in freeze['processing_dependencies'].items():
        with (HERE/path).resolve().open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
        if actual!=digest:raise ValueError('V10 processing dependency changed: '+path)
    return True
@functools.lru_cache(maxsize=64)
def weights(kind,j):
    with np.load(HERE/kind/f'element_{j:02}.npz') as z:return {k:z[k] for k in z.files}
def infer(j,x):
    verify();base=weights('base_weights',j);delta=weights('incremental_weights',j);cl=preprocess.base.head(base,'unified_rebuild_presence_',x)+preprocess.base.head(delta,'presence_delta_',x);reg=np.clip(preprocess.base.head(base,'unified_rebuild_log_',x),np.log(1e-12),np.log(100))+preprocess.base.head(delta,'log_delta_',x);prob=expit(cl);point=np.exp(np.clip(reg,np.log(1e-12),np.log(100)));return np.where(prob>=.9,point,0.),prob,point
def predict(counts):
    verify();s,e,a=preprocess.extract(counts);pred=[];prob=[]
    for j in range(32):
        p,q,_=infer(j,np.r_[s,e[j]][None,:]);pred.append(float(p[0]));prob.append(float(q[0]))
    names=json.loads((HERE/'elements.json').read_text(encoding='utf-8'))
    return dict(version='V10',revision='full-classification-and-quantification-incremental',predicted_element_percent=dict(zip(names,pred)),classification_probability=dict(zip(names,prob)),axis_diagnostics=a,scope='synthetic_numerical_research',formal_report_eligible=False,hardware_validated=False)
def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True,type=pathlib.Path);p.add_argument('--out',required=True,type=pathlib.Path);a=p.parse_args();obj=json.loads(a.input.read_text(encoding='utf-8-sig'));c=preprocess.base.old.anchor_runtime.base.blind_counts(obj);result=predict(c)
    with a.out.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False)
if __name__=='__main__':main()
