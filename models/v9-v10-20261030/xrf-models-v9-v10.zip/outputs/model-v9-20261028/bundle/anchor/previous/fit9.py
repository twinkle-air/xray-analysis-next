"""Joint nonnegative line/escape/scatter fitting, with count-dependent IRLS weights."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import numpy as np
from scipy.optimize import nnls
from pathlib import Path
HERE=Path(__file__).resolve().parent
def load_dictionary(path=None):
    with np.load(path or HERE/'response_dictionary.npz',allow_pickle=False) as z:
        return [(z[f'design_{i}'].copy(),z[f'owners_{i}'].copy()) for i in range(sum(k.startswith('design_') for k in z.files))]
def deviance(y,mu):
    mu=np.maximum(mu,1e-9);nonzero=y>0
    return float(2*(np.sum(mu-y)+np.sum(y[nonzero]*np.log(y[nonzero]/mu[nonzero]))))
def fit_one(counts,dictionary):
    y=np.asarray(counts,dtype=float).reshape(1024,2).sum(axis=1)
    scores=[];fits=[]
    # Every candidate sees the same raw input; no true profile is supplied.
    for a,owners in dictionary:
        expected=np.maximum(y,1)
        for iteration in range(2):
            w=1/np.sqrt(np.maximum(expected,1));aw=a*w[:,None]
            scales=np.maximum(np.linalg.norm(aw,axis=0),1e-12)
            coef,_=nnls(aw/scales,(y*w),maxiter=5000);coef/=scales
            expected=a@coef
        scores.append(deviance(y,expected));fits.append((coef,expected,w,scales))
    selected=int(np.argmin(scores));a,owners=dictionary[selected];coef,expected,w,scales=fits[selected]
    merge=np.array([owners==j for j in range(32)],dtype=float)
    amp=merge@coef
    gram=(a*w[:,None]).T@(a*w[:,None]);normal=gram/np.outer(scales,scales)
    # Local, model-conditional covariance approximation; not certified LOD/coverage.
    covariance=np.linalg.pinv(normal,rcond=1e-12)/np.outer(scales,scales)
    var=np.maximum(np.diag(merge@covariance@merge.T),1e-12)
    snr=amp/np.sqrt(var);sorted_scores=sorted(scores)
    return amp,np.sqrt(var),snr,selected,np.array(scores),float((sorted_scores[1]-sorted_scores[0])/max(sorted_scores[0],1)),coef[owners<0].sum()/max(y.sum(),1)

_DICTIONARY=None
def initialize():
    global _DICTIONARY
    _DICTIONARY=load_dictionary()
def fit_chunk(pair):
    indices,counts=pair
    return indices,[fit_one(c,_DICTIONARY) for c in counts]
