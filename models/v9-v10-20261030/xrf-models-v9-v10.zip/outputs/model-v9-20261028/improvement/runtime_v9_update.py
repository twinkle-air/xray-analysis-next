"""V9 interference-aware relative-error candidate; baseline remains frozen."""
import pathlib,sys,json
import numpy as np
from scipy.special import expit
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import runtime_v9 as baseline
impl=baseline.impl;base=impl.base
def apply(rule,b,point,prob):
    if rule['mode']=='baseline':return b.copy()
    if rule['mode']=='quantification':mask=(b>0)&(point>0)&((b>=.001)==(point>=.001));value=point
    elif rule['mode']=='tail':mask=(b>0)&(point<=rule['ratio']*b);value=point
    else:mask=np.ones(len(b),dtype=bool);value=np.where(prob>=rule['threshold'],point,0.)
    out=b.copy();out[mask]=(1-rule['alpha'])*b[mask]+rule['alpha']*value[mask];return np.clip(out,0,100)
def points(weights,x):
    prob=expit(base.head(weights,'presence_',x));relative=np.clip(base.head(weights,'relative_',x),0,100);log=np.exp(np.clip(base.head(weights,'log_',x),np.log(1e-12),np.log(100)))
    return prob,np.stack([relative,log])
def infer(counts,f,shared,extras,pred):
    config=base.read(HERE/'lines.json');rules=base.read(HERE/'selection.json');out=pred.copy()
    for name,rule in rules.items():
        if rule['mode']=='baseline':continue
        j=config[name]['j'];local=impl.local_features(counts,f['gain_keV_channel'],f['zero_keV'],config[name]['energies_keV']);x=np.c_[shared,extras[:,j],local];prob,point=points(base.load(HERE/f'weights/{name}.npz'),x);out[:,j]=apply(rule,pred[:,j],point[rule['head']],prob)
    return out
def predict(path):
    baseline.verify()
    for rel,digest in base.read(HERE/'freeze.json')['files'].items():
        if base.sha(HERE.parent/rel)!=digest:raise ValueError('V9 improvement changed: '+rel)
    obj=base.read(path);c=base.old.anchor_runtime.base.blind_counts(obj);r=base.old.fit_one(c,base.old.load());f={k:np.array([v]) for k,v in r.items()};prev=base.old.anchor_runtime.base.previous_prediction(c);anchor=base.old.anchor_runtime.infer_cached(base.old.anchor_runtime.model('fusion_model.npz'),c[None,:],f,prev)[0];s,e,h=base.representation(c[None,:],f)
    v6=base.infer_precomputed(base.read(impl.HERE.parents[1]/'selection.json'),s,e,h,anchor);p1=impl.previous.infer(s,e,h,v6);v9=impl.infer(c[None,:],f,s,e,p1);out=infer(c[None,:],f,s,e,v9)[0];names=base.read(impl.HERE.parents[1]/'selection.json')['element_names']
    return {'version':'V9','revision':'interference-relative-error-candidate','formal_report_eligible':False,'hardware_validated':False,'predicted_element_percent':dict(zip(names,out.tolist())),'reported_percent':dict.fromkeys(names),'note':'Synthetic development candidate; scoring zeros are not confirmed absence.'}
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    with pathlib.Path(a.out).open('x',encoding='utf-8') as f:json.dump(predict(a.input),f,ensure_ascii=False,indent=2,allow_nan=False)
