"""Numerical synthetic-spectrum model. No true energy/profile is accepted as a feature."""
import os
for _key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ.setdefault(_key,'1')
import json, argparse
from pathlib import Path
import numpy as np
from scipy.spatial.distance import cdist

def counts_from_blind(blind):
    if set(blind)!={'axis','signal_unit','synthetic','x','counts'}:raise ValueError('Blind schema only: extra metadata rejected')
    x=np.asarray(blind['counts'],dtype=float)
    if blind['axis']!='channel' or blind['signal_unit']!='counts' or blind['synthetic'] is not True or blind['x']!=list(range(2048)):
        raise ValueError('Only synthetic 2048-channel raw spectra evaluated')
    if x.shape!=(2048,) or not np.isfinite(x).all() or (x<0).any() or (x!=np.floor(x)).any() or x.sum()<=0:
        raise ValueError('Finite nonnegative integer counts with positive total required')
    return x

def features(counts,kind):
    c=np.atleast_2d(np.asarray(counts,dtype=float));total=c.sum(axis=1,keepdims=True)
    if kind=='classic':return np.sqrt(c.reshape(len(c),128,16).sum(axis=2)+.375)
    # Both normalized fine/coarse shape and count level are retained.
    # No energy rescaling based on hidden truth and no signal/background subtraction.
    return np.concatenate([np.sqrt((c.reshape(len(c),2048//w,w).sum(axis=2)+.375)/(total+.375*(2048//w))) for w in [4,16]]+[np.log1p(total)],axis=1)

def infer_arrays(model,counts,with_diagnostics=False):
    c=np.atleast_2d(counts);x=(features(c,'multiscale')-model['feature_mean'])/model['feature_scale']
    pred=np.empty((len(c),len(model['elements'])))
    distances=None
    for j in range(len(model['elements'])):
        kind=str(model['selected_kind'][j]);alpha=float(model['selected_alpha'][j]);gamma=float(model['selected_gamma'][j])
        if kind=='ridge':p=x@model['ridge_coefficients'][:,j]+model['target_mean'][j]
        else:
            if distances is None:distances=cdist(x,model['train_features'],'sqeuclidean')
            if kind=='rbf':p=np.exp(-gamma*distances)@model['kernel_coefficients'][:,j]+model['target_mean'][j]
            else:
                k=int(alpha);inds=np.argpartition(distances,k-1,axis=1)[:,:k];d=np.take_along_axis(distances,inds,axis=1)
                w=1/np.maximum(d,1e-12);w/=w.sum(axis=1,keepdims=True)
                p=np.sum(model['train_targets'][inds,j]*w,axis=1)
        pred[:,j]=p
    pred=np.clip(pred,0,100)
    if not with_diagnostics:return pred
    if distances is None:distances=cdist(x,model['train_features'],'sqeuclidean')
    # Distances refer to train-only spectra; validation threshold is descriptive, not a coverage guarantee.
    nearest=distances.min(axis=1)
    return pred,{'nearest_train_squared_distance':nearest.tolist(),'outside_validation_distance_envelope':(nearest>float(model['distance_envelope'])).tolist()}

def predict(model_path,input_path):
    blind=json.loads(Path(input_path).read_text(encoding='utf-8-sig'));counts=counts_from_blind(blind)
    with np.load(model_path,allow_pickle=False) as m:
        p,d=infer_arrays(m,counts,True)
        return {'scope':'round2_synthetic_internal_family_holdout','hardware_validated':False,'supports_unknown_real_device':False,'predicted_element_percent':dict(zip(m['elements'].tolist(),p[0].tolist())),'diagnostics':d,'note':'Estimates are not detection claims. Distance flag is heuristic; a close match does not identify true instrument conditions. No forced 100% closure: oxygen and other matrix elements are not targets.'}

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--model',type=Path,default=Path(__file__).with_name('round2_model.npz'));a.add_argument('--input',type=Path,required=True);a.add_argument('--out',type=Path,required=True);args=a.parse_args()
    result=predict(args.model,args.input)
    with args.out.open('x',encoding='utf8') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False)
