import numpy as np
import solver

def features(counts,gain,zero,spec):
    grid=np.arange(spec['roi'][0],spec['roi'][1]+.005,.02); y,coverage=solver.sample(counts,gain,zero,grid); A=solver.design(grid,spec,sigma=.07)
    bg=solver.snip(y,min(18,(len(grid)-1)//2)); total=np.maximum(counts.sum(axis=1),1); target=[i for i,l in enumerate(spec['lines']) if l['element']==spec['target']];blocks=[];areas=[]
    for background in (None,bg):
        co,cost,kkt=solver.solve(y,A,background);lines=co[:,:-2];area=lines[:,target].sum(axis=1);areas.append(area)
        blocks.append(np.c_[np.log1p(lines),lines/total[:,None],np.log1p(co[:,-2:]),np.log1p(cost/len(grid)),np.log1p(kkt),np.log1p(area),area/total,area/np.maximum(lines.sum(axis=1),1)])
    return np.c_[*blocks,coverage,abs(areas[0]-areas[1])/np.maximum(areas[0]+areas[1],1)].astype(np.float32)
