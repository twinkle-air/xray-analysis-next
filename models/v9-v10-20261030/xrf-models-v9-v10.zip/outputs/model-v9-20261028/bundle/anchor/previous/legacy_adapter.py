"""Exact frozen round-two point estimates; no new fit, thresholds or response parameters."""
import importlib.util,pathlib,sys,json
import numpy as np
HERE=pathlib.Path(__file__).resolve().parent
_MODULE=None;_MODEL=None
def initialize():
 global _MODULE,_MODEL
 directory=HERE/'legacy';sys.path.insert(0,str(directory))
 spec=importlib.util.spec_from_file_location('frozen_round2_runtime',directory/'model.py');_MODULE=importlib.util.module_from_spec(spec);spec.loader.exec_module(_MODULE)
 with np.load(directory/'evidence_model.npz',allow_pickle=False) as f:_MODEL={k:f[k].copy() for k in f.files}
 registry=json.loads((directory/'response_registry.json').read_text(encoding='utf-8'));_MODULE.validate_registry(registry,directory,_MODEL)
 sys.path.remove(str(directory))
def infer(counts):
 if _MODULE is None:initialize()
 mod,m=_MODULE,_MODEL;prior=mod.prior_parameters(m)
 dictionary=[(prior[f'design_{h}'],prior[f'owners_{h}']) for h in range(mod.response_count(prior))]
 c=np.asarray(counts);pf=mod.prior_extract(c,dictionary);pp,base=mod.prior_infer(prior,c,pf['amplitudes'],pf['snr'],pf['hypothesis'],pf['continuum_fraction'])
 d={k:m[k] for k in m if k.startswith(('matrix_','design_','owners_','groups_'))}
 rr=mod.fit_variants(c,int(pf['hypothesis'][0]),pp[0],d)
 f={k:np.array([[rr[mode][k]] for mode in range(len(mod.VARIANT_IDS))]) for k in ('amplitudes','errors','snr','shell','null_delta','deviance','continuum_fraction')}
 values,_,_=mod.infer_cached(m,np.atleast_2d(c),f,pf['hypothesis'],pp,base)
 return values[0]
