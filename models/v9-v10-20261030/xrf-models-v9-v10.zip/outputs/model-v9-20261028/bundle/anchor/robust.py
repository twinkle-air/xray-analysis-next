"""Huber fitting and train-only count/fit-quality influence control."""
import numpy as np
from scipy.linalg import solve

def quality_features(counts,f):
 total=np.asarray(counts).sum(axis=1)
 return np.c_[np.log1p(total),np.log1p(f['deviance']/1024),np.log1p(f['deviance']/total)]

def fit_quality(x,strata,train):
 rules={}
 for key in sorted(set(strata)):
  rows=train&(strata==key)
  if not rows.any():continue
  center=np.median(x[rows],axis=0);scale=np.maximum(1.4826*np.median(abs(x[rows]-center),axis=0),.05)
  rules[str(key)]={'center':center.tolist(),'scale':scale.tolist(),'training_rows':int(rows.sum())}
 return rules

def apply_quality(x,strata,rules):
 z=np.zeros(len(x));unknown=[]
 for key in sorted(set(strata)):
  mask=strata==key
  if str(key) not in rules:unknown.extend(np.flatnonzero(mask).tolist());continue
  rule=rules[str(key)];z[mask]=np.max(abs((x[mask]-rule['center'])/rule['scale']),axis=1)
 return np.maximum(.1,np.minimum(1,8/np.maximum(z,8))),z,unknown

def robust_solve(a,y,w,alpha,intercept=False,scale_floor=.1,iterations=5):
 """Fixed penalty; bounded residual score, positive influence floor; no row deletion."""
 a=np.asarray(a);y=np.asarray(y);w=np.asarray(w);multi=y.ndim==2;pen=np.eye(a.shape[1])*alpha
 if intercept:pen[0,0]=1e-8
 influence=np.ones(len(a));coef=None
 for _ in range(iterations):
  ww=w*influence;coef=solve(a.T@(a*ww[:,None])+pen,a.T@(ww[:,None]*y) if multi else a.T@(ww*y),assume_a='pos')
  residual=y-a@coef;center=np.median(residual,axis=0);scale=np.maximum(1.4826*np.median(abs(residual-center),axis=0),scale_floor)
  z=abs(residual)/scale
  if multi:z=np.max(z,axis=1)
  influence=np.maximum(.02,np.minimum(1,1.345/np.maximum(z,1.345)))
 return coef,influence
