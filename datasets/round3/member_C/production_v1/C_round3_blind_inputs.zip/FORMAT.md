# Member C round-3 blind spectra

One JSON per opaque file: axis=channel, x=0..2047, counts=raw synthetic counts. No element, concentration, profile, family or seed fields.
