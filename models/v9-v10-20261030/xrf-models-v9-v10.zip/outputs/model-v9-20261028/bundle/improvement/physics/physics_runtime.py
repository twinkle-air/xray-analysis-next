"""Count-only energy-aligned local spectral features, with frozen V6 fallback."""
import sys,pathlib,json
import numpy as np
from scipy.special import expit
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import runtime as previous
base=previous.base

def local_features(counts,gain,zero,energies):
    c=np.atleast_2d(counts).astype(float);n=len(c);gain=np.asarray(gain).reshape(n);zero=np.asarray(zero).reshape(n)
    if c.shape[1]!=2048 or not np.isfinite(c).all() or np.any(c<0) or np.any(gain<=0):raise ValueError('Invalid spectral input')
    total=np.maximum(c.sum(axis=1),1);result=[];offset=np.linspace(-.4,.4,41);row=np.arange(n)[:,None]
    for energy in energies:
        channel=(energy+offset[None,:]-zero[:,None])/gain[:,None];valid=(channel>=0)&(channel<=2047);lower=np.floor(channel).astype(int);frac=channel-lower
        value=(1-frac)*c[row,np.clip(lower,0,2047)]+frac*c[row,np.clip(lower+1,0,2047)];value=np.where(valid,value,0.)
        # Side bands are descriptive local background proxies, not certified background fits.
        left=value[:,:8].mean(axis=1);right=value[:,-8:].mean(axis=1);background=left[:,None]+(right-left)[:,None]*np.linspace(0,1,41)
        net=value-background;center=net[:,15:26].sum(axis=1);variance=np.maximum(value[:,15:26].sum(axis=1)+11*(left+right)/2,1)
        result.extend([np.sqrt((value+.375)/(total[:,None]+.375*2048)),np.arcsinh(net/np.sqrt(np.maximum(background,1)))])
        result.append(np.c_[center/np.sqrt(variance),np.arcsinh(center),left/total,right/total,valid.mean(axis=1)])
    out=np.c_[*result].astype(np.float32)
    if not np.isfinite(out).all():raise ValueError('Invalid local features')
    return out

def candidates(weights,x):
    prob=expit(base.head(weights,'presence_',x));log=np.exp(np.clip(base.head(weights,'log_',x),np.log(1e-12),np.log(100)));linear=np.clip(base.head(weights,'linear_',x),0,100)
    return prob,np.stack([log,linear])

def blend(rule,baseline,point,prob):
    if rule['mode']=='baseline':return baseline.copy()
    if rule['mode']=='quantification':
        allow=(baseline>0)&(point>0)&((baseline>=.001)==(point>=.001));p=baseline.copy();p[allow]=(1-rule['alpha'])*baseline[allow]+rule['alpha']*point[allow];return np.clip(p,0,100)
    p=np.where(prob>=rule['threshold'],point,0.)
    return np.clip((1-rule['alpha'])*baseline+rule['alpha']*p,0,100)

def infer(counts,f,shared,extras,baseline):
    config=base.read(HERE/'line_config.json');selection=base.read(HERE/'selection.json');out=baseline.copy()
    for name,rule in selection.items():
        if rule['mode']=='baseline':continue
        j=config[name]['j'];local=local_features(counts,f['gain_keV_channel'],f['zero_keV'],config[name]['energies_keV']);x=np.c_[shared,extras[:,j],local]
        prob,point=candidates(base.load(HERE/f'weights/{name}.npz'),x);out[:,j]=blend(rule,baseline[:,j],point[rule['head']],prob)
    return out

def predict(path):
    freeze=base.read(HERE/'freeze.json')
    for rel,digest in freeze['files'].items():
        if base.sha(HERE.parents[1]/rel)!=digest:raise ValueError('Frozen dependency changed: '+rel)
    obj=base.read(path);c=base.old.anchor_runtime.base.blind_counts(obj);r=base.old.fit_one(c,base.old.load());f={k:np.array([v]) for k,v in r.items()};prev=base.old.anchor_runtime.base.previous_prediction(c)
    anchor=base.old.anchor_runtime.infer_cached(base.old.anchor_runtime.model('fusion_model.npz'),c[None,:],f,prev)[0];s,e,h=base.representation(c[None,:],f)
    v6=base.infer_precomputed(base.read(HERE.parents[1]/'selection.json'),s,e,h,anchor);p1=previous.infer(s,e,h,v6);p=infer(c[None,:],f,s,e,p1)[0];names=base.read(HERE.parents[1]/'selection.json')['element_names']
    return {'version':'V6-local-spectrum-candidate','formal_report_eligible':False,'hardware_validated':False,'predicted_element_percent':dict(zip(names,p.tolist())),'reported_percent':dict.fromkeys(names),'note':'Synthetic development candidate. Zero is not confirmed absence. Local line features use count-inferred calibration only.'}

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--input',required=True);parser.add_argument('--out',required=True);a=parser.parse_args()
    with pathlib.Path(a.out).open('x',encoding='utf-8') as f:json.dump(predict(a.input),f,ensure_ascii=False,indent=2,allow_nan=False)
