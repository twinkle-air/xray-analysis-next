"""V9 spectral-support annotation; numerical predictions remain unchanged."""
import pathlib,sys,functools,json
import numpy as np
HERE=pathlib.Path(__file__).resolve().parent;V=HERE.parent
sys.path.insert(0,str(V/'joint_intensity_quantification/accepted'))
import intensity_runtime as previous
base=previous.base
def verify():
    for name,digest in base.read(HERE/'freeze.json')['files'].items():
        if base.sha(HERE/name)!=digest:raise ValueError('Domain guard dependency changed: '+name)
@functools.lru_cache(maxsize=1)
def weights():return base.load(HERE/'support_model.npz')
def assess(counts):
    c=np.asarray(counts,dtype=float)
    if c.shape!=(2048,) or not np.isfinite(c).all() or np.any(c<0) or c.sum()<=0:raise ValueError('Domain guard requires positive-total2048-channel counts')
    w=weights();x=np.r_[np.sqrt((c.reshape(128,16).sum(1)+.375)/(c.sum()+48)),np.log1p(c.sum())];center=(x-w['median'])/w['scale']-w['pca_mean'];latent=center@w['components'].T;project=float(np.sqrt(np.mean(latent**2/np.maximum(w['variance'],1e-8))));residual=float(np.sqrt(np.mean((center-latent@w['components'])**2)));score=max(project/float(w['project_scale']),residual/float(w['residual_scale']));threshold=float(w['threshold']);outside=bool(score>threshold)
    return dict(status='outside_training_spectral_support' if outside else 'within_training_spectral_support',requires_manual_review=outside,nonconformity_score=score,threshold=threshold,calibration='training-parent-only95percentile',prediction_accuracy_guaranteed=False,note='Spectral-support diagnostic only. Within support does not establish element detectability or concentration accuracy; outside support does not identify a physical cause.')
def predict(path):
    verify();counts=base.old.anchor_runtime.base.blind_counts(base.read(path));support=assess(counts);result=previous.predict(path);result['applicability']=support;result['version']='V9';result['revision']='joint-intensity-with-domain-guard';result['formal_report_eligible']=False;result['hardware_validated']=False
    if support['requires_manual_review']:result['note']='Spectrum outside calibrated training spectral support: numerical estimates require review or additional sample/measurement information.'
    return result
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    with pathlib.Path(a.out).open('x',encoding='utf-8') as f:json.dump(predict(a.input),f,ensure_ascii=False,indent=2,allow_nan=False)
