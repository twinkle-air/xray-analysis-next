"""V9 joint peak/background/nuisance feature experiment."""
import pathlib,sys,json
import numpy as np
from scipy.special import expit
import peak_features
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'improvement'))
import runtime_v9_update as previous
base=previous.base

def apply(rule,b,point,prob):
    out=b.copy()
    if rule['mode']=='baseline':return out
    if rule['mode']=='recovery':mask=np.isfinite(prob)&(b<.001)&(point>=.001)&(prob>=rule['threshold']);value=point
    else:mask=np.isfinite(prob)&(b>=.001)&(prob<rule['threshold']);value=b*rule['scale']
    out[mask]=value[mask];return np.clip(out,0,100)

def infer(c,f,s,e,p):
    out=p.copy();config=base.read(HERE/'lines.json')
    for n,rule in base.read(HERE/'selection.json').items():
        if rule['mode']=='baseline':continue
        spec=config[n];j=spec['j'];local=peak_features.features(c,f['gain_keV_channel'],f['zero_keV'],spec);weights=base.load(HERE/f'weights/{n}.npz');variant=rule['variant'];x=np.c_[s,e[:,j],local[variant]];prob=expit(base.head(weights,variant+'_',x));point=np.exp(np.clip(base.head(weights,'log_',np.c_[s,e[:,j],local['global_calibration']]),np.log(1e-12),np.log(100))) if n in ('Sb','Ba') else p[:,j]
        
        if variant=='confidence':
            d=local['confidence'][:,-4:];limits=weights['trust_limits'];mask=(d[:,0]<=limits[0])&(d[:,1]<=limits[1])&(d[:,2]>=2)&(d[:,3]>0);prob=np.where(mask,prob,np.nan)
        out[:,j]=apply(rule,p[:,j],point,prob)
    return out

def predict(path):
    result=previous.predict(path)
    for rel,digest in base.read(HERE/'freeze.json')['files'].items():
        if base.sha(HERE/rel)!=digest:raise ValueError('Changed peak-fit runtime: '+rel)
    c=base.old.anchor_runtime.base.blind_counts(base.read(path));r=base.old.fit_one(c,base.old.load());f={k:np.array([v]) for k,v in r.items()};s,e,_=base.representation(c[None,:],f);names=base.read(HERE/'elements.json');p=np.array([[result['predicted_element_percent'][n] for n in names]]);out=infer(c[None,:],f,s,e,p)[0];result['revision']='complete-dictionary-calibration';result['predicted_element_percent']=dict(zip(names,out.tolist()));return result

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
    with pathlib.Path(a.out).open('x',encoding='utf-8') as f:json.dump(predict(a.input),f,ensure_ascii=False,indent=2,allow_nan=False)
