"""Poisson objective with explicit background; empirical omitted-element evidence."""
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
import numpy as np
from scipy.optimize import nnls,minimize
from peak_fit_old import deviance

def irls(a,y,iterations=2):
    expected=np.maximum(y,1)
    for _ in range(iterations):
        w=1/np.sqrt(np.maximum(expected,1));aw=a*w[:,None];sc=np.maximum(np.linalg.norm(aw,axis=0),1e-12)
        coef,_=nnls(aw/sc,y*w,maxiter=5000);coef/=sc;expected=a@coef
    return coef
def poisson_refine(a,y,start,return_diagnostics=False,maxiter=100):
    scale=np.maximum(np.linalg.norm(a/np.sqrt(np.maximum(a@start,1))[:,None],axis=0),1e-10);b=a/scale;positive=y>0
    def objective(x):
        mu=np.maximum(b@x,1e-9);value=float(np.sum(mu-y)+np.sum(y[positive]*np.log(y[positive]/mu[positive])))
        return value,b.T@(1-y/mu)
    initial=start*scale;before=objective(initial)[0]
    r=minimize(objective,initial,method='L-BFGS-B',jac=True,bounds=[(0,None)]*len(start),options={'maxiter':maxiter,'ftol':1e-10,'gtol':1e-5,'maxls':30,'maxcor':20})
    accepted=bool(np.isfinite(r.fun) and np.isfinite(r.x).all() and r.fun<=before+1e-7)
    coef=r.x/scale if accepted else start
    converged=bool(r.success and accepted)
    status=('converged' if converged else 'improved_not_converged') if accepted else 'fallback_to_irls'
    diagnostics={'status':status,'success':converged,'optimizer_success':bool(r.success),
        'message':str(r.message),'iterations':int(r.nit),'candidate_accepted':accepted,
        'objective_improvement':float(before-objective(coef*scale)[0]),
        'eligible_for_research_display':converged}
    answer=(coef,converged,diagnostics['objective_improvement'])
    return (*answer,diagnostics) if return_diagnostics else answer
def summarize(a,owners,groups,y,coef):
    mu=np.maximum(a@coef,1e-9);w=1/np.sqrt(np.maximum(mu,1));aw=a*w[:,None];sc=np.maximum(np.linalg.norm(aw,axis=0),1e-12);norm=aw/sc;cov=np.linalg.pinv(norm.T@norm,rcond=1e-12)/np.outer(sc,sc)
    merge=np.array([owners==j for j in range(32)],dtype=float);amp=merge@coef;err=np.sqrt(np.maximum(np.diag(merge@cov@merge.T),1e-12));shell=np.zeros((32,3));null=np.zeros(32)
    for j in range(32):
        cols=owners==j
        for k,s in enumerate('KLM'):
            shell[j,k]=sum(coef[i] for i,g in enumerate(groups) if owners[i]==j and str(g).endswith('_'+s))
        if not cols.any():continue
        keep=~cols;an=aw[:,keep];sn=sc[keep];z,_=nnls(an/sn,y*w,maxiter=5000);zero_mu=a[:,keep]@(z/sn)
        # Conditional WLS nuisance refit, evaluated with Poisson deviance. Not an exact LR test.
        null[j]=deviance(y,zero_mu)-deviance(y,mu)
    return {'amplitudes':amp,'errors':err,'snr':amp/err,'shell':shell,'null_delta':null,'deviance':deviance(y,mu),'continuum_fraction':coef[owners<0].sum()/max(y.sum(),1)}
def fit_variants(counts,h,prior_prediction,dictionary):
    y=np.asarray(counts,dtype=float).reshape(1024,2).sum(axis=1);owners=dictionary[f'owners_{h}'];groups=dictionary[f'groups_{h}'];fixed=dictionary[f'design_{h}'];start=irls(fixed,y)
    ratio=prior_prediction[13]/max(prior_prediction[13]+prior_prediction[3]+prior_prediction[2],1e-9);low,high=dictionary['matrix_positions'];weight=float(np.clip((ratio-low)/(high-low),0,1));adaptive=(1-weight)*dictionary[f'matrix_0_{h}']+weight*dictionary[f'matrix_1_{h}']
    candidates=[]
    for mode,a in enumerate([fixed,fixed,adaptive]):
        coef=start if mode<2 else irls(a,y);converged=False;gain=0.
        solver={'status':'fixed_two_step_irls','success':None,'message':'Two iterations; convergence not asserted',
            'iterations':2,'candidate_accepted':True,'objective_improvement':0.,'eligible_for_research_display':True}
        if mode:coef,converged,gain,solver=poisson_refine(a,y,coef,return_diagnostics=True)
        d=summarize(a,owners,groups,y,coef);d.update(converged=converged,likelihood_improvement=gain,matrix_weight=weight,solver=solver);candidates.append(d)
    return candidates
