"""Bounded exact kernel memoization with three isolated batch processes."""
from __future__ import annotations
import argparse, ctypes, datetime, importlib.util, json, os, pathlib, subprocess, sys, time
from ctypes import wintypes

HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('recovery_base',HERE/'recover_isolated.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
REC=HERE/'parallel_v4';STATE=REC/'state.json';GIB=1024**3

class MemoryStatus(ctypes.Structure):
    _fields_=[('length',wintypes.DWORD),('load',wintypes.DWORD),('total_phys',ctypes.c_ulonglong),('avail_phys',ctypes.c_ulonglong),('total_page',ctypes.c_ulonglong),('avail_page',ctypes.c_ulonglong),('total_virtual',ctypes.c_ulonglong),('avail_virtual',ctypes.c_ulonglong),('avail_extended',ctypes.c_ulonglong)]
def memory():
    m=MemoryStatus();m.length=ctypes.sizeof(m)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise ctypes.WinError()
    return {'available_physical_bytes':m.avail_phys,'available_commit_bytes':m.avail_page,'memory_load_percent':m.load}
def config():
    c=read(REC/'runtime_config.json')
    if type(c.get('max_workers')) is not int or not 1<=c['max_workers']<=3:raise ValueError('max_workers must be 1..3')
    if not isinstance(c.get('physical_launch_reserve_GiB'),(int,float)) or not 3<=c['physical_launch_reserve_GiB']<=32:raise ValueError('Physical reserve must be 3..32 GiB')
    if not isinstance(c.get('commit_launch_reserve_GiB'),(int,float)) or not 7<=c['commit_launch_reserve_GiB']<=64:raise ValueError('Commit reserve must be 7..64 GiB')
    return c
def allow_launch(active,m,c=None):
    c=config() if c is None else c
    return active<c['max_workers'] and m['available_physical_bytes']>=c['physical_launch_reserve_GiB']*GIB and m['available_commit_bytes']>=c['commit_launch_reserve_GiB']*GIB
def now():return base.now()
def write(p,d):base.write(p,d)
def read(p):return base.read(p)

class Adopted:
    def __init__(self,pid):
        self.pid=pid;self.returncode=None
        k=ctypes.windll.kernel32
        k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
        k.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)]
        k.CloseHandle.argtypes=[wintypes.HANDLE]
        self.handle=k.OpenProcess(0x100000|0x1000,False,pid)
        if not self.handle:raise ctypes.WinError()
    def poll(self):
        if self.returncode is not None:return self.returncode
        code=wintypes.DWORD()
        if not ctypes.windll.kernel32.GetExitCodeProcess(self.handle,ctypes.byref(code)):raise ctypes.WinError()
        if code.value!=259:
            self.returncode=code.value;ctypes.windll.kernel32.CloseHandle(self.handle)
        return self.returncode

def child(bid):
    policy=read(REC/'execution_policy.json')
    if base.digest(pathlib.Path(__file__))!=policy['controller_sha256']:raise ValueError('Controller differs from validated policy')
    if base.digest(HERE/'exact_kernel_cache.py')!=policy['adapter_sha256']:raise ValueError('Execution adapter differs from validated policy')
    verification=read(REC/'exact_cache_verification.json')
    if verification.get('status')!='passed' or verification['adapter_sha256']!=policy['adapter_sha256']:raise ValueError('No matching exact-equivalence verification')
    r=base.runner();r.worker_init(str(base.REPO),str(base.FREEZE),str(base.RELEASE),'A',str(base.OUT),10)
    from exact_kernel_cache import install
    cache,boundaries=install(policy['cache_maximum_accounted_bytes'])
    batch=next(b for b in base.batches() if b['batch_id']==bid)
    receipt={'batch_id':bid,'started_at_utc':now(),'adapter_sha256':policy['adapter_sha256'],'physics_core_sha256':base.digest(base.FREEZE/'generator/fp_competition/core.py'),'frozen_production_tool_sha256':base.digest(base.TOOLS/'run_member.py'),'optimization':'exact primitive memoization; no stored spectra; full simulate called on every generation/replay record','independent_replay_cache_clear_required':True}
    receipt['status']='running';write(REC/'optimization_receipts'/(bid+'.json'),receipt)
    try:
        result=r.run_batch(batch)
        if not boundaries:raise ValueError('Independent replay cache-reset boundary was not observed')
        write(REC/'verified_batches'/(bid+'.json'),result)
        receipt.update(status='passed_all_records',records=result['records'])
        print(json.dumps({'batch_id':bid,'status':result['status'],'records':result['records']}),flush=True)
    except BaseException as exc:
        receipt.update(status='failed_partial_preserved',error_type=type(exc).__name__,error=str(exc));raise
    finally:
        receipt.update(finished_at_utc=now(),cache_stats=cache.stats(),replay_boundaries=boundaries,cache_cleared_before_independent_replay=bool(boundaries) and all(b['entries_at_independent_replay_start']==0 for b in boundaries))
        write(REC/'optimization_receipts'/(bid+'.json'),receipt)

def supervise(handoff_path):
    if STATE.exists():raise FileExistsError('Parallel state exists; inspect before restart')
    handoff=read(handoff_path);plan=base.batches();valid_ids={b['batch_id'] for b in plan}
    adopted=handoff.get('adopted_batches',[])
    if len({b['batch_id'] for b in adopted})!=len(adopted) or any(b['batch_id'] not in valid_ids for b in adopted):raise ValueError('Duplicate or unknown adopted batch')
    active={};results={};failed=[];pending=[]
    state={'status':'validating_handoff','started_at_utc':now(),'supervisor_pid':os.getpid(),**config(),'isolation':'fresh_process_per_batch','handoff':handoff,'code_sha256':base.digest(pathlib.Path(__file__))}
    write(STATE,state)
    try:
        for entry in adopted:
            active[entry['batch_id']]={'process':Adopted(entry['pid']),'adopted':True,'started_at_utc':entry.get('started_at_utc',handoff['at_utc']),'streams':[]}
        r=base.runner();r.worker_init(str(base.REPO),str(base.FREEZE),str(base.RELEASE),'A',str(base.OUT),10)
        write(REC/'preflight.json',r.dry_run(base.REPO,base.FREEZE,base.RELEASE,'A'))
        for b in plan:
            bid=b['batch_id']
            if bid in active:continue
            summary=base.OUT/'reports'/bid/'summary.json'
            if summary.exists():
                # The frozen resume verifier checks archive hash/CRC and full QC evidence.
                results[bid]=r.run_batch(b)
            else:
                artifacts=[base.OUT/'sealed_batches'/bid,base.OUT/'reports'/bid,base.OUT/'archives'/(bid+'.zip')]
                if any(p.exists() for p in artifacts):raise ValueError('Unowned partial batch retained: '+bid)
                pending.append(b)
        write(REC/'resume_verified.json',{'batches':len(results),'records':sum(x['records'] for x in results.values()),'freeze_manifest_sha256':base.digest(base.FREEZE/'freeze_manifest.json'),'original_runner_sha256':base.digest(base.TOOLS/'run_member.py')})
        while active or pending:
            for bid,entry in list(active.items()):
                code=entry['process'].poll()
                if code is None:continue
                for stream in entry['streams']:stream.close()
                summary=base.OUT/'reports'/bid/'summary.json'
                if code!=0 or not summary.exists():
                    failed.append({'batch_id':bid,'exit_code':code,'partial_preserved':True})
                else:
                    try:results[bid]=r.run_batch(next(b for b in plan if b['batch_id']==bid))
                    except BaseException as exc:failed.append({'batch_id':bid,'error':str(exc),'partial_preserved':True})
                del active[bid]
            mem=memory();cfg=config()
            if pending and not failed and allow_launch(len(active),mem,cfg):
                b=pending.pop(0);bid=b['batch_id'];log=REC/'logs'/bid;log.parent.mkdir(parents=True,exist_ok=True)
                so=log.with_suffix('.stdout.log').open('wb');se=log.with_suffix('.stderr.log').open('wb')
                try:
                    proc=subprocess.Popen([sys.executable,'-B','-u',str(pathlib.Path(__file__).resolve()),'--batch',bid],cwd=base.ROOT,stdout=so,stderr=se,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
                except BaseException:
                    so.close();se.close();raise
                active[bid]={'process':proc,'adopted':False,'started_at_utc':now(),'streams':[so,se]}
            state.update(**cfg,status='draining_after_failure' if failed else 'running',updated_at_utc=now(),passed_batches=len(results),passed_records=sum(x['records'] for x in results.values()),pending_batches=len(pending),active_batches=[{'batch_id':bid,'pid':e['process'].pid,'adopted':e['adopted'],'started_at_utc':e['started_at_utc']} for bid,e in active.items()],failures=failed,memory=mem)
            write(STATE,state)
            if int(time.monotonic())//10!=state.get('_last_history_tick'):
                state['_last_history_tick']=int(time.monotonic())//10
                with (REC/'resource_history.jsonl').open('a',encoding='utf-8') as history:
                    history.write(json.dumps({'at_utc':now(),'active_batches':[b for b in active],'passed_batches':len(results),'pending_batches':len(pending),'memory':mem,'config':cfg})+'\n')
            if failed and not active:raise RuntimeError('Batch failure; stopped new launches and preserved all data')
            time.sleep(2)
        if len(results)!=400 or sum(x['records'] for x in results.values())!=40000:raise ValueError('Incomplete batch coverage')
        state.update(status='finalizing',updated_at_utc=now());write(STATE,state)
        command=[sys.executable,'-B','-u',str(base.TOOLS/'run_member.py'),'--repository',str(base.REPO),'--freeze',str(base.FREEZE),'--release',str(base.RELEASE),'--member','A','--out',str(base.OUT),'--workers','1','--minimum-free-gib','10','--include-sealed-qc']
        with (REC/'finalize.stdout.log').open('wb') as so,(REC/'finalize.stderr.log').open('wb') as se:subprocess.run(command,cwd=base.ROOT,stdout=so,stderr=se,check=True)
        summary=read(base.OUT/'selfcheck_summary.json')
        if summary.get('actual_records')!=40000 or summary.get('packaging_status')!='complete':raise ValueError('Incomplete final delivery')
        # Include external execution provenance in the eventual delivery inventory.
        import zipfile
        evidence=base.OUT/'reports'/'exact_kernel_execution_v4.zip'
        files=[(HERE/'exact_kernel_cache.py','exact_kernel_cache.py'),(HERE/'verify_exact_kernel_cache.py','verify_exact_kernel_cache.py'),(pathlib.Path(__file__),'produce_parallel_v4.py')]
        files += [(REC/name,name) for name in ('execution_policy.json','exact_cache_verification.json','scheduler_checks.json','runtime_config.json','handoff.json')]
        files += [(p,'optimization_receipts/'+p.name) for p in sorted((REC/'optimization_receipts').glob('*.json'))]
        with zipfile.ZipFile(evidence,'x',zipfile.ZIP_DEFLATED) as z:
            for path,name in files:z.write(path,name)
        with zipfile.ZipFile(evidence) as z:
            if z.testzip() is not None:raise ValueError('Optimization evidence CRC failed')
            for path,name in files:
                import hashlib
                if hashlib.sha256(z.read(name)).hexdigest()!=base.digest(path):raise ValueError('Optimization provenance hash mismatch')
        manifest=read(base.OUT/'delivery_manifest.json')
        manifest['files'].append({'path':evidence.relative_to(base.OUT).as_posix(),'bytes':evidence.stat().st_size,'sha256':base.digest(evidence)})
        manifest['execution_optimization']={'kind':'bounded exact-input primitive cache','evidence':evidence.relative_to(base.OUT).as_posix(),'adapter_sha256':base.digest(HERE/'exact_kernel_cache.py'),'physics_equations_changed':False,'independent_replay_boundary_cache_reset':True}
        write(base.OUT/'delivery_manifest.json',manifest)
        state.update(status='complete_pending_coordinator_acceptance',finished_at_utc=now(),summary=summary);write(STATE,state)
    except BaseException as exc:
        state.update(status='failed_partial_preserved',updated_at_utc=now(),error_type=type(exc).__name__,error=str(exc),active_batches=[{'batch_id':bid,'pid':e['process'].pid} for bid,e in active.items()]);write(STATE,state);raise

if __name__=='__main__':
    os.environ.update(PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    p=argparse.ArgumentParser();p.add_argument('--batch');p.add_argument('--handoff',type=pathlib.Path);args=p.parse_args()
    if args.batch:child(args.batch)
    elif args.handoff:supervise(args.handoff)
    else:p.error('--batch or --handoff required')
