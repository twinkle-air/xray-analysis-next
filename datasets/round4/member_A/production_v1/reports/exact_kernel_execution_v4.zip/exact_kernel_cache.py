"""Bounded exact-input memoization; does not approximate or alter FP equations.

The original primitive runs on every miss. Keys contain all input bits. Clear
between generation and independent replay; never cache spectra or Poisson draws.
"""
from __future__ import annotations
from collections import OrderedDict
import struct,time

class ExactKernelCache:
    def __init__(self,original,max_bytes=128*1024**2):
        if type(max_bytes) is not int or max_bytes<1:raise ValueError('Positive byte budget required')
        self.original=original;self.limit=max_bytes;self.items=OrderedDict();self.bytes=0;self.grids={};self.grid_bytes=0;self.next_grid=0
        self.hits=0;self.misses=0;self.evictions=0;self.peak_bytes=0;self.original_seconds=0.
    def __call__(self,t,mu):
        # Full bytes are keys: no rounding, energy bins, or hash-only matching.
        grid=(t.dtype.str,t.shape,t.tobytes(order='C'))
        if grid not in self.grids:
            # Intern exact grid bytes once, rather than once per fluorescence line.
            if len(self.grids)>=8:self.clear()
            grid_size=len(grid[2])+512
            if grid_size>self.limit:return self.original(t,mu)
            while self.items and self.bytes+self.grid_bytes+grid_size>self.limit:
                _,(_,old_size)=self.items.popitem(last=False);self.bytes-=old_size;self.evictions+=1
            if self.grid_bytes+grid_size>self.limit:self.clear()
            self.grids[grid]=self.next_grid;self.next_grid+=1;self.grid_bytes+=grid_size
        key=(self.grids[grid],struct.pack('!d',float(mu)))
        if key in self.items:
            self.hits+=1;out,size=self.items.pop(key);self.items[key]=(out,size);return out.copy()
        self.misses+=1;start=time.perf_counter();out=self.original(t,mu);self.original_seconds+=time.perf_counter()-start
        size=out.nbytes+512
        if size+self.grid_bytes<=self.limit:
            while self.items and self.bytes+self.grid_bytes+size>self.limit:
                _,(_,old_size)=self.items.popitem(last=False);self.bytes-=old_size;self.evictions+=1
            saved=out.copy();saved.setflags(write=False);self.items[key]=(saved,size);self.bytes+=size;self.peak_bytes=max(self.peak_bytes,self.bytes+self.grid_bytes)
        return out
    def clear(self):
        self.items.clear();self.bytes=0;self.grids.clear();self.grid_bytes=0
    def stats(self):
        return {'hits':self.hits,'misses':self.misses,'evictions':self.evictions,'cache_entries':len(self.items),'accounted_bytes':self.bytes+self.grid_bytes,'peak_accounted_bytes':self.peak_bytes,'maximum_accounted_bytes':self.limit,'original_primitive_seconds':self.original_seconds,'key':'exact dtype, shape, array bytes, float64 mu bits','cached_object':'kernel primitive only; full simulate still called for every record'}

def install(max_bytes=128*1024**2):
    from fp_competition import core,dataset
    if isinstance(core._kernel_primitive,ExactKernelCache):raise RuntimeError('Cache already installed')
    cache=ExactKernelCache(core._kernel_primitive,max_bytes)
    original_replay=dataset.replay_dataset;boundaries=[]
    def independent_replay(*args,**kwargs):
        before=cache.stats();cache.clear()
        boundaries.append({'before':before,'entries_at_independent_replay_start':len(cache.items)})
        return original_replay(*args,**kwargs)
    core._kernel_primitive=cache;dataset.replay_dataset=independent_replay
    return cache,boundaries
