"""Verify package integrity, compile runtime sources, optionally smoke-test both models."""
import pathlib,json,hashlib,argparse,tempfile,subprocess,sys
H=pathlib.Path(__file__).resolve().parent
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--smoke',action='store_true');a=ap.parse_args()
    manifest=json.loads((H/'integrity.json').read_text(encoding='utf-8'))
    for rel,digest in manifest.items():
        p=(H/rel).resolve();assert p.is_relative_to(H)
        with p.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==digest,rel
    scripts=list(H.rglob('*.py'))
    for p in scripts:compile(p.read_text(encoding='utf-8-sig'),str(p),'exec')
    if a.smoke:
        import numpy as np
        for version,entry in [('V9','model-v9-20261028/domain_guard/domain_runtime.py'),('V10','model-v10-20261030/runtime_v10.py')]:
            with tempfile.TemporaryDirectory(prefix='xrf-smoke-') as td:
                out=pathlib.Path(td)/'result.json';p=subprocess.run([sys.executable,'-B',str(H/'outputs'/entry),'--input',str(H/'examples/synthetic_blind.json'),'--out',str(out)],capture_output=True,text=True)
                if p.returncode:raise RuntimeError(p.stderr)
                obj=json.loads(out.read_text(encoding='utf-8'));expected=json.loads((H/f'examples/expected_{version}.json').read_text(encoding='utf-8'))
                assert obj['version']==version and obj['formal_report_eligible'] is False and obj['hardware_validated'] is False
                got=obj['predicted_element_percent'];want=expected['predicted_element_percent'];assert set(got)==set(want)
                np.testing.assert_allclose([got[k] for k in want],list(want.values()),rtol=1e-9,atol=1e-10)
    print(json.dumps({'status':'pass','files_checked':len(manifest),'python_sources_compiled':len(scripts),'smoke':a.smoke}))
if __name__=='__main__':main()
