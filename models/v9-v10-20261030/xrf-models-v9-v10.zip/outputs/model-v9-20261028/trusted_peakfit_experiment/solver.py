"""Joint nonnegative Gaussian-line fits with SNIP and nuisance profiling.

Weighted least squares is an approximation, not a calibrated detection test.
Channel-to-energy mappings come only from the existing counts-only estimator.
"""
import numpy as np

def snip(y,width=18):
    z=np.log1p(np.log1p(np.sqrt(np.maximum(y,0)+1)))
    for k in range(width,0,-1):
        z[:,k:-k]=np.minimum(z[:,k:-k],(z[:,:-2*k]+z[:,2*k:])/2)
    return np.maximum(np.expm1(np.expm1(z))**2-1,0)

def design(grid,spec,shift=0.,slope=0.,sigma=.07):
    columns=[];center=grid.mean()
    for line in spec['lines']:
        energy=line['energy'];mu=energy+shift+slope*(energy-center)
        col=np.exp(-.5*((grid-mu)/sigma)**2);columns.append(col/max(col.sum(),1e-20))
    t=np.linspace(0,1,len(grid));return np.c_[*columns,1-t,t]

def solve(y,A,background=None,omit=()):
    # Coordinate descent on convex nonnegative weighted least squares.
    weight=1/np.maximum(y,1);yy=y if background is None else y-background
    outer=(A[:,:,None]*A[:,None,:]).reshape(len(A),-1)
    gram=(weight@outer).reshape(len(y),A.shape[1],A.shape[1]);rhs=(weight*yy)@A
    coeff=np.zeros_like(rhs);diagonal=np.maximum(np.diagonal(gram,axis1=1,axis2=2),1e-20)
    for _ in range(45):
        for j in range(A.shape[1]):
            if j in omit:continue
            residual=rhs[:,j]-np.sum(gram[:,j,:]*coeff,axis=1)
            coeff[:,j]=np.maximum(coeff[:,j]+residual/diagonal[:,j],0)
    residual=yy-coeff@A.T;cost=np.sum(weight*residual**2,axis=1)
    gradient=np.einsum('nij,nj->ni',gram,coeff)-rhs
    active=np.ones(coeff.shape[1],bool);active[list(omit)]=False
    violation=np.max(np.abs(np.where(coeff>1e-9,gradient,np.minimum(gradient,0)))[:,active],axis=1)
    return coeff,cost,violation

def sample(counts,gain,zero,grid):
    n=len(counts);channel=(grid[None,:]-zero[:,None])/gain[:,None];valid=(channel>=0)&(channel<=2047);lo=np.floor(channel).astype(int);f=channel-lo;r=np.arange(n)[:,None]
    y=(1-f)*counts[r,np.clip(lo,0,2047)]+f*counts[r,np.clip(lo+1,0,2047)]
    return np.where(valid,y,0),valid.mean(axis=1)

def features(counts,gain,zero,spec):
    counts=np.atleast_2d(counts).astype(float);gain=np.asarray(gain).reshape(-1);zero=np.asarray(zero).reshape(-1)
    if counts.shape[1]!=2048 or not np.isfinite(counts).all() or np.any(counts<0) or np.any(gain<=0) or not np.isfinite(gain+zero).all():raise ValueError('Invalid spectrum/calibration')
    grid=np.arange(spec['roi'][0],spec['roi'][1]+.005,.02);y,coverage=sample(counts,gain,zero,grid);bg=snip(y,min(18,(len(grid)-1)//2));total=np.maximum(counts.sum(axis=1),1);target=tuple(i for i,l in enumerate(spec['lines']) if l['element']==spec['target']);scenarios=[(0.,0.,.07),(-.025,0.,.07),(.025,0.,.07),(0.,-.003,.07),(0.,.003,.07),(0.,0.,.045),(0.,0.,.10)];allstats=[]
    for background in (None,bg):
        stats=[]
        for shift,slope,sigma in scenarios:
            A=design(grid,spec,shift,slope,sigma);co,cost,kkt=solve(y,A,background);_,null,_=solve(y,A,background,target)
            amplitude=co[:,target].sum(axis=1);interference=co[:,:-2].sum(axis=1)-amplitude
            stats.append(np.c_[np.log1p(amplitude),amplitude/total,np.sqrt(np.maximum(null-cost,0)),cost/len(grid),np.log1p(interference),amplitude/np.maximum(amplitude+interference,1),kkt])
        allstats.append(np.stack(stats,axis=1))
    linear,snipped=allstats
    # Three controlled feature sets: fixed linear, fixed SNIP, SNIP + nuisance profile.
    fixedlinear=np.c_[linear[:,0],coverage];fixedsnip=np.c_[snipped[:,0],coverage,np.mean(bg,axis=1)/np.maximum(y.mean(axis=1),1)]
    best=np.argmin(snipped[:,:,3],axis=1);profile=np.c_[fixedsnip,snipped.min(axis=1),np.median(snipped,axis=1),snipped.max(axis=1),snipped[np.arange(len(y)),best],best/6.,np.std(snipped[:,:,0],axis=1)]
    return {'linear_fixed':fixedlinear.astype(np.float32),'snip_fixed':fixedsnip.astype(np.float32),'snip_profile':profile.astype(np.float32)}
