"""Complete frozen local dictionary, full-spectrum registration and trust features."""
import numpy as np
from scipy.signal import find_peaks
import solver

def calibrate(counts,gain,zero,anchors):
    g=gain.copy();z=zero.copy();valid=np.zeros(len(counts),bool);rms=np.ones(len(counts));span=np.zeros(len(counts))
    for i,c in enumerate(counts):
        sm=np.convolve(c,[.25,.5,.25],mode='same');pk,_=find_peaks(sm,prominence=5*np.sqrt(max(np.median(sm),1)),distance=4);ener=pk*gain[i]+zero[i];pairs=[]
        for k,en in zip(pk,ener):
            distances=abs(np.asarray(anchors)-en);order=np.argsort(distances)
            if distances[order[0]]<.08 and distances[order[1]]-distances[order[0]]>.04:pairs.append((k,anchors[order[0]]))
        if len(pairs)<3:continue
        x,y=np.array(pairs).T;keep=np.ones(len(x),bool)
        for _ in range(3):
            if keep.sum()<3:break
            gg,zz=np.polyfit(x[keep],y[keep],1);error=abs(gg*x+zz-y);keep=error<.04
        if keep.sum()<3:continue
        gg,zz=np.polyfit(x[keep],y[keep],1);rr=np.sqrt(np.mean((gg*x[keep]+zz-y[keep])**2));ss=np.ptp(y[keep]);rms[i]=rr;span[i]=ss
        if ss>=2 and abs(gg/gain[i]-1)<=.015 and abs(zz-zero[i])<=.08 and rr<=.025:g[i]=gg;z[i]=zz;valid[i]=True
    return g,z,valid,rms,span

def fit_features(counts,gain,zero,spec):
    grid=np.arange(spec['roi'][0],spec['roi'][1]+.005,.02);y,coverage=solver.sample(counts,gain,zero,grid);bg=solver.snip(y[None,:][0],min(18,(len(grid)-1)//2));total=np.maximum(counts.sum(axis=1),1);target=tuple(i for i,l in enumerate(spec['lines']) if l['element']==spec['target']);features=[];areas=[];qualities=[];companions=[]
    for background in (None,bg):
        A=solver.design(grid,spec,sigma=.07);co,cost,kkt=solver.solve(y,A,background);_,null,_=solver.solve(y,A,background,target);area=co[:,target].sum(axis=1);areas.append(area);qualities.append(np.sqrt(cost/len(grid)));companions.append((co[:,target]>1.).sum(axis=1));interference=co[:,:-2].sum(axis=1)-area
        features.append(np.c_[np.log1p(area),area/total,np.sqrt(np.maximum(null-cost,0)),cost/len(grid),np.log1p(interference),area/np.maximum(area+interference,1),kkt,companions[-1]])
    instability=abs(areas[0]-areas[1])/np.maximum(areas[0]+areas[1],1)
    return np.c_[*features,coverage,instability],np.c_[qualities[1],instability,companions[1]]

def features(counts,gain,zero,spec):
    c=np.atleast_2d(counts).astype(float);g=np.asarray(gain).reshape(-1);z=np.asarray(zero).reshape(-1)
    if not np.isfinite(c).all() or np.any(c<0) or np.any(g<=0):raise ValueError('Invalid spectrum')
    fixed,_=fit_features(c,g,z,spec);gg,zz,ok,rms,span=calibrate(c,g,z,spec['anchors']);glob,diagnostics=fit_features(c,gg,zz,spec);globalfeatures=np.c_[glob,ok,rms,span,(gg/g-1),zz-z];trust=np.c_[diagnostics,ok]
    return {'dictionary_only':fixed.astype(np.float32),'global_calibration':globalfeatures.astype(np.float32),'confidence':np.c_[globalfeatures,trust].astype(np.float32)}
