"""Paired full-100-record pipeline timing on an existing frozen training batch."""
from __future__ import annotations
import argparse,datetime,json,os,pathlib,subprocess,sys,time,shutil
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
HERE=pathlib.Path(__file__).resolve().parent
import recover_isolated as base
DEST=base.ROOT/'outputs/round4-A-batch-speed-benchmark-20261026'
BID='R4_A_train_stage3_development_0011'

def write(p,d):base.write(p,d)
def read(p):return base.read(p)
def now():return base.now()
def child(mode):
    start=time.perf_counter();r=base.runner();out=DEST/'temporary_runs'/mode
    out.mkdir(parents=True,exist_ok=False)
    r.worker_init(str(base.REPO),str(base.FREEZE),str(base.RELEASE),'A',str(out),10)
    b=next(b for b in base.batches() if b['batch_id']==BID)
    if b['usage']!='train':raise ValueError('Timing may use training only')
    cache=None;boundaries=[]
    if mode=='optimized':
        from exact_kernel_cache import install
        verification=read(HERE/'parallel_v4/exact_cache_verification.json')
        if verification['status']!='passed' or base.digest(HERE/'exact_kernel_cache.py')!=verification['adapter_sha256']:raise ValueError('Unverified adapter')
        cache,boundaries=install()
    result=r.run_batch(b)
    elapsed=time.perf_counter()-start
    cmd=read(out/'reports'/BID/'commands.json')
    inventory=[]
    for record in read(out/'sealed_batches'/BID/'manifest.json')['records']:
        inventory.append({k:record[k] for k in ('id','blind_input_sha256','full_results_sha256')})
    report={'status':'passed_full_pipeline','mode':mode,'batch_id':BID,'records':100,'pipeline_seconds':result['seconds'],'end_to_end_child_seconds':elapsed,'generation_seconds':next(x['seconds'] for x in cmd if x['action']=='generate_dataset'),'archive_sha256':result['archive_sha256'],'source_freeze_sha256':base.digest(base.FREEZE/'freeze_manifest.json'),'records_sha256':inventory,'full_QC':result,'cache':cache.stats() if cache else None,'independent_replay_boundaries':boundaries}
    if cache and not boundaries:raise ValueError('No independent replay reset')
    for name in ('audit.json','replay.json','window_budget.json','commands.json','summary.json','actual_record_index.csv'):
        source=out/'reports'/BID/name;target=DEST/'evidence'/mode/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    write(DEST/(mode+'_result.json'),report)

def main():
    state_path=DEST/'state.json'
    if state_path.exists():raise FileExistsError('Benchmark already has state')
    state={'status':'running','started_at_utc':now(),'supervisor_pid':os.getpid(),'batch_id':BID,'records_per_arm':100,'order':['baseline','optimized'],'selection':'completed Stage3 batch at the faster end of historic timings; one paired example, not a representative aggregate','separate_process_per_arm':True,'background_production_continues':True,'original_core_sha256':base.digest(base.FREEZE/'generator/fp_competition/core.py'),'adapter_sha256':base.digest(HERE/'exact_kernel_cache.py'),'script_sha256':base.digest(pathlib.Path(__file__))}
    write(state_path,state)
    try:
        for mode in state['order']:
            state.update(phase=mode,phase_started_at_utc=now());write(state_path,state)
            with (DEST/(mode+'.stdout.log')).open('wb') as so,(DEST/(mode+'.stderr.log')).open('wb') as se:
                p=subprocess.Popen([sys.executable,'-B','-u',str(pathlib.Path(__file__).resolve()),'--mode',mode],cwd=base.ROOT,stdout=so,stderr=se,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
                state['child_pid']=p.pid
                while p.poll() is None:
                    state.update(updated_at_utc=now());write(state_path,state);time.sleep(5)
                if p.returncode:raise RuntimeError(mode+' exited '+str(p.returncode))
        a=read(DEST/'baseline_result.json');b=read(DEST/'optimized_result.json')
        if a['records_sha256']!=b['records_sha256']:raise ValueError('Baseline/optimized full or blind file hash differs')
        prod=read(base.OUT/'sealed_batches'/BID/'manifest.json')['records']
        expected=[{k:x[k] for k in ('id','blind_input_sha256','full_results_sha256')} for x in prod]
        if expected!=a['records_sha256']:raise ValueError('Benchmark differs from original production data')
        for d in (a,b):
            if d['full_QC']['status']!='passed_all_records':raise ValueError('Missing full QC')
        gain=a['pipeline_seconds']/b['pipeline_seconds'];reduction=1-b['pipeline_seconds']/a['pipeline_seconds']
        report={'status':'passed_paired_full_batch_measurement','batch_id':BID,'records_per_arm':100,'original_pipeline_seconds':a['pipeline_seconds'],'optimized_pipeline_seconds':b['pipeline_seconds'],'original_generation_seconds':a['generation_seconds'],'optimized_generation_seconds':b['generation_seconds'],'speedup':gain,'elapsed_reduction_fraction':reduction,'original_end_to_end_seconds':a['end_to_end_child_seconds'],'optimized_end_to_end_seconds':b['end_to_end_child_seconds'],'all_100_blind_and_full_file_hashes_match_each_other_and_original_production':True,'both_all_record_audit_replay_window_and_ZIP_passed':True,'cache_stats':b['cache'],'limitations':['One completed Stage3 training batch chosen from faster historic cases; do not extrapolate to all recipes','Sequential baseline then optimized, under live background production; CPU frequency, contention and filesystem cache may vary','Includes generation plus full audit/replay/window/pack; excludes later member-wide packaging'],'source_freeze_sha256':a['source_freeze_sha256'],'measured_at_utc':now()}
        write(DEST/'report.json',report)
        text=f'''# 100 条整批流程提速实测

批次 `{BID}`，同一冻结配方、条件、种子，原流程与缓存流程分别用全新进程顺序执行。正式生产持续运行。

| 指标 | 原流程 | 缓存流程 |
|---|---:|---:|
| 完整流程 | {a['pipeline_seconds']/60:.2f} 分钟 | {b['pipeline_seconds']/60:.2f} 分钟 |
| 其中生成 | {a['generation_seconds']/60:.2f} 分钟 | {b['generation_seconds']/60:.2f} 分钟 |
| 其中重算、其他核验及打包 | {(a['pipeline_seconds']-a['generation_seconds'])/60:.2f} 分钟 | {(b['pipeline_seconds']-b['generation_seconds'])/60:.2f} 分钟 |

本批实测约 **{gain:.2f} 倍速度**，耗时减少 **{reduction*100:.1f}%**。两组均完成全部 100 条 audit/replay、窗口检查和 ZIP 核验；两组 100 个盲输入及完整结果文件 SHA-256 逐条一致，并与原生产记录一致。缓存重算入口清空记录保存在 optimized_result.json。

这是单批实测。选择了历史较快的一个训练批次，以控制测量额外资源开销；不能代表全部剩余配方。原流程先运行、缓存流程后运行，后台三路生产持续，未锁定 CPU 频率或系统负载。原流程与缓存流程均从新进程开始。此计时不含所有成员数据完成后的总汇打包。

测试副本不进入训练集，结果证据保存后删除临时出谱副本；正式生产数据不改动。
'''
        (DEST/'整批提速实测.md').write_text(text,encoding='utf-8')
        # Delete only this benchmark's two known temporary outputs after preserving evidence.
        temp_root=(DEST/'temporary_runs').resolve()
        if not temp_root.is_relative_to(DEST.resolve()):raise ValueError('Unsafe benchmark cleanup root')
        for mode in ('baseline','optimized'):
            target=(temp_root/mode).resolve()
            if target.parent!=temp_root or not target.is_relative_to(DEST.resolve()):raise ValueError('Unsafe benchmark cleanup target')
            shutil.rmtree(target)
        temp_root.rmdir()
        state.update(status='complete',finished_at_utc=now(),report='report.json',temporary_spectrum_copies_removed=True);write(state_path,state)
    except BaseException as exc:
        state.update(status='failed_preserved',updated_at_utc=now(),error_type=type(exc).__name__,error=str(exc));write(state_path,state);raise

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['baseline','optimized']);args=p.parse_args()
    if args.mode:child(args.mode)
    else:main()
