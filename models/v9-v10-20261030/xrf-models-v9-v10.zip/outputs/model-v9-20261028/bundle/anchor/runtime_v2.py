"""Element evidence is mandatory; geometry and matrix corrections use counts only."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ.setdefault(k,'1')
import argparse,hashlib,importlib.util,json,pathlib,sys
import numpy as np
from scipy.special import expit
from spectral_fit import load,fit_one
HERE=pathlib.Path(__file__).resolve().parent;MAJOR=np.array([0,1,2,3,4,5,6,7,8,9,12,13]);PREVIOUS=None;PM=None
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def initialize_previous():
 global PREVIOUS,PM
 root=HERE/'previous';sys.path.insert(0,str(root));spec=importlib.util.spec_from_file_location('v1_point_estimator',root/'model_runtime.py');PREVIOUS=importlib.util.module_from_spec(spec);spec.loader.exec_module(PREVIOUS)
 with np.load(root/'round3_model.npz',allow_pickle=False) as z:PM={k:z[k].copy() for k in z.files}
 sys.path.remove(str(root))
def previous_prediction(counts):
 if PREVIOUS is None:initialize_previous()
 d=[(PM[f'design_{h}'],PM[f'owners_{h}']) for h in range(9)];r=PREVIOUS.fit_one(counts,d)
 f={name:np.array([r[i]]) for i,name in enumerate(['amplitudes','errors','snr','hypothesis','deviance','hypothesis_margin','continuum_fraction'])}
 old=PREVIOUS.legacy_adapter.infer(counts)[None,:] if np.any(PM['selected_kind']==0) else np.zeros((1,32))
 return PREVIOUS.infer_cached(PM,np.atleast_2d(counts),f,old)[0]
def blind_counts(obj):
 if set(obj)!={'axis','signal_unit','synthetic','x','counts'}:raise ValueError('No truth/profile/seed/energy metadata allowed')
 if obj['axis']!='channel' or obj['signal_unit']!='counts' or obj['synthetic'] is not True or obj['x']!=list(range(2048)):raise ValueError('Only native synthetic 2048-channel counts supported')
 if any(type(v) not in (int,float) for v in obj['counts']):raise ValueError('Counts must be numbers, not booleans or strings')
 c=np.asarray(obj['counts'],dtype=float)
 if c.shape!=(2048,) or not np.isfinite(c).all() or np.any(c<0) or np.any(c!=np.floor(c)) or c.sum()<=0:raise ValueError('Invalid counts')
 return c
def spectral_features(c):
 c=np.atleast_2d(c);total=c.sum(axis=1,keepdims=True)
 return np.c_[*[np.sqrt((c.reshape(len(c),2048//w,w).sum(axis=2)+.375)/(total+.375*(2048//w))) for w in [4,16]],np.log1p(total)]
def matrix_features(c,f):
 total=np.atleast_2d(c).sum(axis=1)
 return np.c_[np.sqrt(np.maximum(f['amplitudes'][:,MAJOR],0)/total[:,None]),np.log1p(total),f['continuum_fraction'],np.log(f['gain_keV_channel']),f['zero_keV'],np.log(f['noise_fwhm_eV'])]
def polynomial(x,degree):
 if degree==1:return np.c_[np.ones(len(x)),x]
 a,b=np.triu_indices(x.shape[1]);return np.c_[np.ones(len(x)),x,x[:,a]*x[:,b]]
def classifier_features(c,f,j):
 total=np.atleast_2d(c).sum(axis=1);shell=f['shell'][:,j];fractions=shell/np.maximum(shell.sum(axis=1,keepdims=True),1e-12)
 return np.c_[matrix_features(c,f),np.sqrt(np.maximum(f['amplitudes'],0)/total[:,None]),np.arcsinh(f['null_delta'][:,j]),np.arcsinh(f['snr'][:,j]),np.log1p(f['amplitudes'][:,j]),np.log1p(f['errors'][:,j]),fractions,np.log1p(f['deviance']/1024)]
def quantification(m,c,f):
 x=(spectral_features(c)-m['feature_mean'])/m['feature_scale'];ridge=np.array([np.clip(x@a+m['target_mean'],0,100) for a in m['ridge_coefficients']])
 matrix=(matrix_features(c,f)-m['matrix_mean'])/m['matrix_scale'];total=np.atleast_2d(c).sum(axis=1);physical=[]
 for i,degree in enumerate(m['physical_degrees']):
  eta=np.clip(polynomial(matrix,int(degree))@m[f'physical_coeff_{i}'],m['physical_low'][i],m['physical_high'][i]);physical.append(np.clip(f['amplitudes']/total[:,None]*np.exp(eta),0,100))
 return ridge,np.array(physical)
def classifier(m,c,f):
 p=np.empty((len(np.atleast_2d(c)),32))
 for j in range(32):
  x=(classifier_features(c,f,j)-m['classifier_mean'][j])/m['classifier_scale'][j];p[:,j]=expit(x@m['classifier_coeff'][j,1:]+m['classifier_coeff'][j,0])
 return p
def infer_cached(m,c,f,previous):
 ridge,physical=quantification(m,c,f);prob=classifier(m,c,f);baseline=None
 if np.any(m['selected_kind']==3):
  with np.load(HERE/'baseline_model.npz',allow_pickle=False) as z:bm={k:z[k] for k in z.files}
  baseline=infer_cached(bm,c,f,previous)[0]
 raw=np.empty((len(np.atleast_2d(c)),32));threshold=np.zeros_like(raw)
 for j in range(32):
  kind=int(m['selected_kind'][j]);k=int(m['selected_quant'][j]);raw[:,j]=baseline[:,j] if kind==3 else previous[:,j] if kind==0 else ridge[k,:,j] if kind==1 else physical[k,:,j]
  threshold[:,j]=m['null_thresholds'][f['regime'].astype(int),j,int(m['selected_null_quantile'][j])]
 hard=(f['amplitudes']>0)&(f['snr']>=.5)&(f['null_delta']>0)
 support=hard&(f['null_delta']>=threshold)&(f['snr']>=m['selected_snr_cut'])&(prob>=m['selected_classifier_threshold'])
 return np.where(support,raw,0.),raw,prob,support,threshold
def predict(path):
 freeze=json.loads((HERE/'selection_freeze.json').read_text(encoding='utf-8'));assert sha(HERE/'model.npz')==freeze['model_sha256']
 for name,digest in freeze['runtime_sha256'].items():
  if sha(HERE/name)!=digest:raise ValueError('Frozen runtime changed: '+name)
 c=blind_counts(json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig')));d=load();r=fit_one(c,d)
 f={k:np.array([v]) for k,v in r.items()}
 with np.load(HERE/'model.npz',allow_pickle=False) as z:m={k:z[k].copy() for k in z.files}
 previous=previous_prediction(c) if np.any(np.isin(m['selected_kind'],[0,3])) else np.zeros((1,32))
 values,raw,prob,support,threshold=infer_cached(m,c[None,:],f,previous)
 return {'version':'unified-r123-robust-v3','scope':'synthetic_numerical_research','formal_report_eligible':False,'hardware_validated':False,'predicted_element_percent':dict(zip(m['elements'].tolist(),values[0].tolist())),'unfiltered_point_estimate_percent':dict(zip(m['elements'].tolist(),raw[0].tolist())),'reported_percent':dict.fromkeys(m['elements'].tolist()),'element_evidence':{str(e):{'status':'conditional_signal_supported' if support[0,j] else 'insufficient_spectral_evidence','fitted_signal_counts':float(r['amplitudes'][j]),'conditional_SNR':float(r['snr'][j]),'omitted_element_deviance_improvement':float(r['null_delta'][j]),'empirical_zero_threshold':float(threshold[0,j]),'classifier_score':float(prob[0,j]),'classifier_score_is_calibrated_probability':False,'zero_is_confirmed_absence':False,'scoring_zero_for_unsupported':not bool(support[0,j])} for j,e in enumerate(m['elements'])},'response':{'candidate':str(d['response_ids'][r['hypothesis']]),'normalized_response_aliases':{str(d['response_ids'][i]):str(d['response_ids'][root]) for i,root in d['aliases'].items()},'refined_gain_keV_channel':r['gain_keV_channel'],'refined_zero_keV':r['zero_keV'],'effective_noise_fwhm_eV':float(r['noise_fwhm_eV']),'initial_deviance':r['initial_deviance'],'refined_deviance':r['deviance'],'geometry_optimizer_converged':r['geometry_converged'],'true_instrument_identified':False},'note':'Conditional signal support is not a certified detection or quantitative uncertainty claim. Insufficient evidence is not absence. Unsupported scoring zeros remain in FN/accuracy denominators. Exposed regression is not a fresh blind test.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--input',required=True,type=pathlib.Path);p.add_argument('--out',required=True,type=pathlib.Path);a=p.parse_args()
 if a.out.exists():raise FileExistsError(a.out)
 answer=predict(a.input)
 with a.out.open('x',encoding='utf-8') as out:json.dump(answer,out,ensure_ascii=False,indent=2,allow_nan=False)
