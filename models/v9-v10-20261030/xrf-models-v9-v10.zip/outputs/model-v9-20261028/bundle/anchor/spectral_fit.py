"""Bounded response refinement and conditional omitted-element spectral evidence."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import json,pathlib,time
import numpy as np
from scipy.optimize import nnls,least_squares
from scipy.ndimage import gaussian_filter1d
HERE=pathlib.Path(__file__).resolve().parent
def deviance(y,mu):
 mu=np.maximum(mu,1e-9);positive=y>0
 return float(2*(np.sum(mu-y)+np.sum(y[positive]*np.log(y[positive]/mu[positive]))))
def irls(a,y,iterations=2):
 mu=np.maximum(y,1.);last=None
 for _ in range(iterations):
  weight=1/np.sqrt(np.maximum(mu,1));aw=a*weight[:,None];scale=np.maximum(np.linalg.norm(aw,axis=0),1e-12)
  coef,_=nnls(aw/scale,y*weight,maxiter=5000);coef/=scale;mu=a@coef
  if last is not None and np.linalg.norm(coef-last)<=1e-6*max(np.linalg.norm(coef),1.):break
  last=coef.copy()
 return coef
def load():
 with np.load(HERE/'response_dictionary.npz',allow_pickle=False) as z:d={k:z[k].copy() for k in z.files}
 ids=d['response_ids'].tolist();assert ids==['P1','P2','P3','D1','D2','D3','D4','D5','D6']
 d['profiles']=[json.loads((HERE/'profiles'/f'{name}.json').read_text(encoding='utf-8-sig')) for name in ids]
 roots=[];aliases={}
 for h in range(len(ids)):
  alias=next((i for i in roots if d[f'design_{i}'].shape==d[f'design_{h}'].shape and np.max(abs(d[f'design_{i}']-d[f'design_{h}']))<1e-10),None)
  if alias is None:roots.append(h);alias=h
  aliases[h]=alias
 d['roots']=roots;d['aliases']=aliases
 return d
def warped(a,theta,gain):
 # theta units: gain/0.01, zero/0.05keV, extra Gaussian sigma in two-channel bins.
 fraction=theta[0]*.01;zero=theta[1]*.05;sigma=theta[2]
 smooth=gaussian_filter1d(a,sigma,axis=0,mode='constant',truncate=4.) if sigma>.02 else a
 grid=np.arange(1024);coordinate=(grid+.25)*(1+fraction)-.25+zero/(2*gain)
 lower=np.floor(coordinate).astype(int);part=coordinate-lower
 out=(smooth[np.clip(lower,0,1023)]*(1-part[:,None])+smooth[np.clip(lower+1,0,1023)]*part[:,None])*(1+fraction)
 out[(coordinate<0)|(coordinate>1023)]=0
 norm=out.sum(axis=0);return out/np.where(norm>1e-30,norm,1.)
def fit_one(counts,d,route_scores=None):
 y=np.asarray(counts,dtype=float).reshape(1024,2).sum(axis=1)
 if route_scores is None:
  scores=np.full(9,np.inf)
  for h in d['roots']:
   a=d[f'design_{h}'];coef=irls(a,y);scores[h]=deviance(y,a@coef)
 else:scores=np.asarray(route_scores,dtype=float).copy()
 h=min(d['roots'],key=lambda i:scores[i]);a0=d[f'design_{h}'];owners=d[f'owners_{h}'];profile=d['profiles'][h]
 start=irls(a0,y);mu0=a0@start;score0=deviance(y,mu0);weight=1/np.sqrt(np.maximum(mu0,1))
 best={'score':score0,'theta':np.zeros(3),'a':a0,'coef':start}
 def residual(theta):
  a=warped(a0,theta,profile['gain_keV_channel']);aw=a*weight[:,None];scale=np.maximum(np.linalg.norm(aw,axis=0),1e-12)
  coef,_=nnls(aw/scale,y*weight,maxiter=5000);coef/=scale;mu=a@coef;score=deviance(y,mu)
  if score<best['score']:best.update(score=score,theta=theta.copy(),a=a,coef=coef)
  return (mu-y)*weight
 solved=least_squares(residual,np.array([0.,0.,.35]),bounds=([-1.5,-1.6,0.],[1.5,1.6,1.8]),max_nfev=12,ftol=1e-5,xtol=1e-4,gtol=1e-4,x_scale=[1.,1.,.5],diff_step=1e-3)
 # Never accept an objective-worse refinement; a numerical fallback stays explicit.
 a=best['a'];coef=irls(a,y,iterations=5);mu=a@coef;full_score=deviance(y,mu)
 if full_score>best['score']+1e-7:coef=best['coef'];mu=a@coef;full_score=best['score']
 w=1/np.sqrt(np.maximum(mu,1));aw=a*w[:,None];sc=np.maximum(np.linalg.norm(aw,axis=0),1e-12)
 covariance=np.linalg.pinv((aw/sc).T@(aw/sc),rcond=1e-12)/np.outer(sc,sc)
 merge=np.array([owners==j for j in range(32)],dtype=float);amp=merge@coef;error=np.sqrt(np.maximum(np.diag(merge@covariance@merge.T),1e-12));snr=amp/error
 delta=np.zeros(32);shell=np.zeros((32,3));groups=d[f'groups_{h}']
 for j in range(32):
  selected=owners==j
  for k,s in enumerate('KLM'):shell[j,k]=sum(coef[i] for i,g in enumerate(groups) if owners[i]==j and str(g).endswith('_'+s))
  if not selected.any() or amp[j]<=1e-12:continue
  keep=~selected;coef_null,_=nnls(aw[:,keep]/sc[keep],y*w,maxiter=5000);mu_null=a[:,keep]@(coef_null/sc[keep])
  delta[j]=deviance(y,mu_null)-full_score
 theta=best['theta'];gain=profile['gain_keV_channel']*(1+theta[0]*.01);zero=profile['zero_keV']+theta[1]*.05
 noise=np.sqrt(profile['noise_fwhm_eV']**2+(2.354820045*2*profile['gain_keV_channel']*theta[2]*1000)**2)
 return {'amplitudes':amp,'errors':error,'snr':snr,'null_delta':delta,'shell':shell,'hypothesis':h,'continuum_fraction':coef[owners<0].sum()/max(y.sum(),1),'deviance':full_score,'initial_deviance':score0,'gain_keV_channel':gain,'zero_keV':zero,'noise_fwhm_eV':noise,'geometry_theta':theta,'geometry_converged':bool(solved.success),'geometry_accepted':bool(best['score']<score0),'geometry_nfev':int(solved.nfev),'regime':int(gain<.01)}
