"""Durable launcher/status recorder for the authorized A full-quota job."""
from __future__ import annotations
import datetime,json,os,pathlib,shutil,subprocess,sys,time

HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parents[1]
REPO=ROOT/'outputs/round4-global-freeze-20261025/snapshot'
OUT=ROOT/'outputs/round4-A-production-20261025'
FREEZE=REPO/'datasets/round4/shared/freeze_v1'
RELEASE=REPO/'datasets/round4/shared/releases/production_release_v1.json'
RUNNER=REPO/'datasets/round4/shared/production_tools/run_member.py'

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def write(p,d):
    temp=p.with_suffix(p.suffix+'.writing')
    temp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    temp.replace(p)

def progress():
    generated=0;active=0;passed=0;verified=0;failures=[]
    for p in (OUT/'sealed_batches').glob('*/manifest.json'):
        try:
            m=read(p);generated+=m.get('spectrum_count',len(m.get('records',[])))
            active+=m.get('status')=='running'
        except (OSError,ValueError):pass
    for p in (OUT/'reports').glob('*/summary.json'):
        try:
            m=read(p)
            if m.get('status')=='passed_all_records':passed+=1;verified+=m['records']
        except (OSError,ValueError):pass
    for p in (OUT/'reports').glob('*/failure.json'):
        try:failures.append(read(p))
        except (OSError,ValueError):pass
    return {'generated_records_manifest_committed':generated,'active_generation_batches':active,'fully_QC_passed_batches':passed,'fully_QC_passed_records':verified,'failed_batches':failures,'disk_free_bytes':shutil.disk_usage(ROOT).free}

def main():
    if (HERE/'state.json').exists():raise FileExistsError('A supervisor state already exists; inspect it before launching a second job')
    release=read(RELEASE)
    if release.get('production_approved') is not True:raise ValueError('Release is not approved')
    command=[sys.executable,'-B','-u',str(RUNNER),'--repository',str(REPO),'--freeze',str(FREEZE),'--release',str(RELEASE),'--member','A','--out',str(OUT),'--workers','4','--minimum-free-gib','10','--include-sealed-qc','--preflight-report',str(HERE/'A_preflight.json')]
    env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    start=now();log=HERE/'production.stdout.log';err=HERE/'production.stderr.log'
    with log.open('wb') as stdout,err.open('wb') as stderr:
        child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL)
        state={'status':'running','member':'A','expected_records':40000,'expected_batches':400,'workers':4,'supervisor_pid':os.getpid(),'runner_pid':child.pid,'started_at_utc':start,'source_main_commit':'b7e6b347d8388b0ecc47a18a32022fe5e19bda82','freeze_manifest_sha256':release['freeze_manifest_sha256'],'command':command,'output_directory':str(OUT),'stdout_log':str(log),'stderr_log':str(err),'pilot_spectra':0}
        write(HERE/'launch.json',state)
        while child.poll() is None:
            write(HERE/'state.json',{**state,'updated_at_utc':now(),**progress()})
            time.sleep(20)
        code=child.wait()
    final=progress();summary=read(OUT/'selfcheck_summary.json') if (OUT/'selfcheck_summary.json').exists() else None
    complete=code==0 and summary is not None and summary.get('actual_records')==40000 and summary.get('packaging_status')=='complete' and (OUT/'delivery_manifest.json').is_file()
    write(HERE/'state.json',{**state,**final,'status':'complete_pending_coordinator_acceptance' if complete else 'failed_or_partial_preserved','updated_at_utc':now(),'finished_at_utc':now(),'exit_code':code,'selfcheck_summary':summary,'delivery_manifest':str(OUT/'delivery_manifest.json') if complete else None})
    if not complete:raise SystemExit(code or 1)

if __name__=='__main__':main()
