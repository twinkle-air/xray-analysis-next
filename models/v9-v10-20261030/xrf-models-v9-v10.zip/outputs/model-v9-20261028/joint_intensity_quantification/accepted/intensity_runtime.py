"""V9 user-selected joint-intensity quantification revision and entry point."""
import pathlib,sys,json
import numpy as np
HERE=pathlib.Path(__file__).resolve().parent;V=HERE.parents[1]
sys.path.insert(0,str(V/'trusted_peakfit_experiment'))
import peak_runtime as previous
sys.path.insert(0,str(HERE))
import intensity_features
base=previous.base
def predict(path):
    for rel,digest in base.read(HERE/'freeze.json')['files'].items():
        if base.sha(HERE/rel)!=digest:raise ValueError('V9 joint-intensity dependency changed: '+rel)
    result=previous.predict(path);counts=base.old.anchor_runtime.base.blind_counts(base.read(path));f={k:np.array([v]) for k,v in base.old.fit_one(counts,base.old.load()).items()};s,e,_=base.representation(counts[None,:],f);names=base.read(HERE/'elements.json');lines=base.read(HERE/'lines.json');out=result['predicted_element_percent'].copy()
    for name in ('Co','Sn'):
        if out[name]<=0:continue
        j=names.index(name);local=intensity_features.features(counts[None,:].astype(float),f['gain_keV_channel'],f['zero_keV'],lines[name]);x=np.c_[s,e[:,j],local];weights=base.load(HERE/f'{name}.npz');out[name]=float(np.exp(np.clip(base.head(weights,'log_',x)[0],np.log(1e-12),np.log(100))))
    result['predicted_element_percent']=out;result['version']='V9';result['revision']='joint-intensity-quantification';return result
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    with pathlib.Path(a.out).open('x',encoding='utf-8') as f:json.dump(predict(a.input),f,ensure_ascii=False,indent=2,allow_nan=False)
