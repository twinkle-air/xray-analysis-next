"""Research estimates, evidence decisions and formal report eligibility are distinct."""
import os
for key in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS'):
    os.environ.setdefault(key, '1')
import argparse
import json
from pathlib import Path
import numpy as np
from scipy.special import expit
from prior_model import infer_cached as prior_infer, extract_counts as prior_extract, matrix_raw, polynomial, base_model
from baseline_model import counts_from_blind, infer_arrays as baseline_infer
from evidence_fit import fit_variants
from contracts import response_count, validate_registry, VARIANT_IDS,sha
HERE = Path(__file__).resolve().parent

def prior_parameters(m):
    return {k[6:]: m[k] for k in m if k.startswith('prior_')}

def calibration(m, mode, counts, f, hyp):
    total=np.atleast_2d(counts).sum(axis=1); amp=f['amplitudes'][mode]
    raw=matrix_raw(amp,total,f['continuum_fraction'][mode]); out=np.zeros_like(amp)
    if (hyp<0).any() or (hyp>=m['cal_mean'].shape[1]).any():
        raise ValueError('Unknown response hypothesis')
    for h in range(m['cal_mean'].shape[1]):
        mask=hyp==h
        if not mask.any():continue
        x=(raw[mask]-m['cal_mean'][mode,h])/m['cal_scale'][mode,h]
        eta=np.clip(polynomial(x,2)@m['cal_coeff'][mode,h],m['cal_low'][mode,h],m['cal_high'][mode,h])
        out[mask]=amp[mask]/total[mask,None]*np.exp(eta)
    return np.clip(out,0,100)

def evidence_features(mode,j,counts,f,prior,baseline,raw_quant):
    total=np.atleast_2d(counts).sum(axis=1);amp=f['amplitudes'][mode];error=f['errors'][mode];snr=f['snr'][mode]
    null=f['null_delta'][mode,:,j];shell=f['shell'][mode,:,j];sf=shell/np.maximum(shell.sum(axis=1,keepdims=True),1e-12)
    context=matrix_raw(amp,total,f['continuum_fraction'][mode])
    z=np.c_[np.sign(null)*np.log1p(abs(null)),np.arcsinh(snr[:,j]),np.log1p(amp[:,j]),np.log1p(error[:,j]),np.arcsinh(prior[:,j]/.001),np.arcsinh(baseline[:,j]/.001),np.arcsinh(raw_quant[:,j]/.001),sf,context,np.log1p(f['deviance'][mode])]
    return np.c_[z,np.tanh(z)**2]

def infer_cached(m,counts,f,hyp,prior,baseline):
    pred=prior.copy();prob=np.full_like(pred,np.nan);supported=np.zeros_like(pred,dtype=bool)
    for mode in range(m['cal_mean'].shape[0]):
        quant=calibration(m,mode,counts,f,hyp)
        for j in np.where(m['selected_mode']==mode)[0]:
            x=evidence_features(mode,int(j),counts,f,prior,baseline,quant);x=(x-m['clf_mean'][mode,j])/m['clf_scale'][mode,j]
            pp=expit(x@m['clf_coeff'][mode,j,1:]+m['clf_coeff'][mode,j,0]);prob[:,j]=pp
            weight=float(m['selected_blend'][j]);value=weight*quant[:,j]+(1-weight)*prior[:,j]
            gate=pp>=m['selected_threshold'][j];supported[:,j]=gate;pred[:,j]=np.where(gate,value,0)
    return np.clip(pred,0,100),prob,supported

def element_details(m,values,scores,supported,snr,solver):
    result={}
    for j,element in enumerate(m['elements']):
        mode=int(m['selected_mode'][j]);evaluated=mode>=0;ok=evaluated and bool(supported[j])
        fit_ok=evaluated and solver[mode]['eligible_for_research_display']
        if not evaluated:status='estimate_requires_review'
        elif not fit_ok:status='fit_requires_review'
        elif not ok:status='insufficient_evidence_not_confirmed_absence'
        elif values[j]<.001:status='supported_below_research_display_threshold'
        else:status='signal_supported_within_synthetic_model'
        result[str(element)]={'status':status,'evidence_evaluated':evaluated,
            'evidence_decision':('supported' if ok else 'insufficient') if evaluated else 'not_evaluated',
            'reported_percent':None,'formal_report_eligible':False,
            'research_display_percent':float(values[j]) if ok and fit_ok and values[j]>=.001 else None,
            'point_estimate_percent':float(values[j]),'evidence_score':float(scores[j]) if evaluated else None,
            'calibrated_real_device_probability':False,'fit_variant':mode,
            'conditional_peak_snr':float(snr[mode,j]) if evaluated else None}
    return result

def predict(model_path,input_path):
    c=counts_from_blind(json.loads(Path(input_path).read_text(encoding='utf-8-sig')));model_path=Path(model_path)
    with np.load(model_path,allow_pickle=False) as z:m={k:z[k].copy() for k in z.files}
    registry=json.loads(model_path.with_name('response_registry.json').read_text(encoding='utf8'))
    ids=validate_registry(registry,model_path.parent,m);prior=prior_parameters(m)
    dictionary=[(prior[f'design_{h}'],prior[f'owners_{h}']) for h in range(response_count(prior))]
    pf=prior_extract(c,dictionary);pp,base=prior_infer(prior,c,pf['amplitudes'],pf['snr'],pf['hypothesis'],pf['continuum_fraction'])
    _,distance=baseline_infer(base_model(prior),c,with_diagnostics=True)
    d={k:m[k] for k in m if k.startswith(('matrix_','design_','owners_','groups_'))}
    rr=fit_variants(c,int(pf['hypothesis'][0]),pp[0],d)
    f={k:np.array([[rr[mode][k]] for mode in range(len(VARIANT_IDS))]) for k in ('amplitudes','errors','snr','shell','null_delta','deviance','continuum_fraction')}
    values,scores,support=infer_cached(m,np.atleast_2d(c),f,pf['hypothesis'],pp,base);solver=[r['solver'] for r in rr]
    hypothesis={'candidate_id':ids[int(pf['hypothesis'][0])],'candidate_index':int(pf['hypothesis'][0]),
        'candidate_ids':ids,'true_instrument_condition_identified':False,'deviance':pf['deviance'][0].tolist(),
        'relative_margin':float(pf['hypothesis_margin'][0]),'ambiguous':bool(pf['hypothesis_margin'][0]<.05),
        'ambiguity_rule':'legacy heuristic margin<0.05; not calibrated coverage'}
    return {'schema_version':2,'version':'round2-hardened-20261023','model_sha256':sha(model_path),
        'response_registry_sha256':sha(model_path.with_name('response_registry.json')),
        'scope':'synthetic_known_response_internal_research','hardware_validated':False,
        'supports_unknown_real_device':False,'formal_report_eligible':False,
        'predicted_element_percent':dict(zip(m['elements'].tolist(),values[0].tolist())),
        'element_report':element_details(m,values[0],scores[0],support[0],f['snr'][:,0],solver),
        'response_hypothesis':hypothesis,'distribution_diagnostics':distance,
        'solver_diagnostics':dict(zip(VARIANT_IDS,solver)),
        'note':'Research only. Unassessed evidence is not support; insufficient evidence is not absence. Point estimates remain in scoring. Scores, SNR and 10ppm display threshold are not certified probability/LOD.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--model',type=Path,default=HERE/'evidence_model.npz')
    parser.add_argument('--input',type=Path,required=True);parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    if args.out.exists():raise FileExistsError(args.out)
    answer=predict(args.model,args.input)
    with args.out.open('x',encoding='utf8') as stream:json.dump(answer,stream,ensure_ascii=False,indent=2,allow_nan=False)
