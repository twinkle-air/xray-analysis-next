"""Nine-candidate synthetic quantitative research model; strict blind-only input."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ.setdefault(key,'1')
import argparse,hashlib,json,pathlib
import numpy as np
from scipy.special import expit
from fit9 import fit_one
import legacy_adapter
HERE=pathlib.Path(__file__).resolve().parent
MAJOR=np.array([0,1,2,3,4,5,6,7,8,9,12,13])
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def blind_counts(obj):
 if set(obj)!={'axis','signal_unit','synthetic','x','counts'}:raise ValueError('Only the native blind-count schema is accepted; truth/profile/seed metadata forbidden')
 if obj['axis']!='channel' or obj['signal_unit']!='counts' or obj['synthetic'] is not True or obj['x']!=list(range(2048)):raise ValueError('Synthetic 2048-channel raw counts required')
 c=np.asarray(obj['counts'],dtype=float)
 if c.shape!=(2048,) or not np.isfinite(c).all() or np.any(c<0) or np.any(c!=np.floor(c)) or c.sum()<=0:raise ValueError('Invalid counts')
 return c
def spectral_features(counts):
 c=np.atleast_2d(counts).astype(float);total=c.sum(axis=1,keepdims=True)
 return np.c_[*[np.sqrt((c.reshape(len(c),2048//w,w).sum(axis=2)+.375)/(total+.375*(2048//w))) for w in [4,16]],np.log1p(total)]
def matrix_features(counts,f):
 c=np.atleast_2d(counts);total=c.sum(axis=1)
 return np.c_[np.sqrt(np.maximum(f['amplitudes'][:,MAJOR],0)/total[:,None]),np.log1p(total),f['continuum_fraction'],np.eye(9)[f['hypothesis'].astype(int)]]
def polynomial(x,degree):
 if degree==1:return np.c_[np.ones(len(x)),x]
 a,b=np.triu_indices(x.shape[1]);return np.c_[np.ones(len(x)),x,x[:,a]*x[:,b]]
def classifier_features(counts,f,j):
 total=np.atleast_2d(counts).sum(axis=1)
 return np.c_[matrix_features(counts,f),np.sqrt(np.maximum(f['amplitudes'],0)/total[:,None]),np.log1p(f['amplitudes'][:,j]),np.arcsinh(f['snr'][:,j])]
def physical_predictions(m,counts,f):
 x=(matrix_features(counts,f)-m['physical_mean'])/m['physical_scale'];total=np.atleast_2d(counts).sum(axis=1);out=[]
 for i,degree in enumerate(m['physical_degrees']):
  eta=np.clip(polynomial(x,int(degree))@m[f'physical_coeff_{i}'],m['physical_low'][i],m['physical_high'][i])
  out.append(np.clip(f['amplitudes']/total[:,None]*np.exp(eta),0,100))
 return np.array(out)
def probabilities(m,counts,f):
 values=np.empty((len(np.atleast_2d(counts)),32))
 for j in range(32):
  x=(classifier_features(counts,f,j)-m['classifier_mean'][j])/m['classifier_scale'][j]
  values[:,j]=expit(x@m['classifier_coeff'][j,1:]+m['classifier_coeff'][j,0])
 return values
def infer_cached(m,counts,f,legacy):
 c=np.atleast_2d(counts);x=(spectral_features(c)-m['feature_mean'])/m['feature_scale']
 ridge=np.clip(np.array([x@coef+m['target_mean'] for coef in m['ridge_coefficients']]),0,100)
 physical=physical_predictions(m,c,f);probs=probabilities(m,c,f);out=np.empty((len(c),32))
 for j in range(32):
  kind=int(m['selected_kind'][j]);idx=int(m['selected_quant'][j])
  v=legacy[:,j] if kind==0 else (ridge[idx,:,j] if kind==1 else physical[idx,:,j])
  gate=(probs[:,j]>=m['selected_threshold'][j])&(f['snr'][:,j]>=m['selected_snr_cut'][j])
  out[:,j]=np.where(gate,v,0)
 return out,probs
def predict(input_path):
 model=HERE/'round3_model.npz';freeze=json.loads((HERE/'selection_freeze.json').read_text(encoding='utf-8'))
 if sha(model)!=freeze['model_sha256']:raise ValueError('Frozen model changed')
 for name,digest in freeze['runtime_sha256'].items():
  if sha(HERE/name)!=digest:raise ValueError('Frozen runtime/dependency changed: '+name)
 c=blind_counts(json.loads(pathlib.Path(input_path).read_text(encoding='utf-8-sig')))
 with np.load(model,allow_pickle=False) as z:m={k:z[k].copy() for k in z.files}
 ids=m['response_ids'].tolist()
 if ids!=['P1','P2','P3','D1','D2','D3','D4','D5','D6']:raise ValueError('Invalid development response allowlist')
 dictionary=[(m[f'design_{h}'],m[f'owners_{h}']) for h in range(len(ids))];r=fit_one(c,dictionary)
 f={k:np.array([r[i]]) for i,k in enumerate(['amplitudes','errors','snr','hypothesis','deviance','hypothesis_margin','continuum_fraction'])}
 old=legacy_adapter.infer(c)[None,:] if np.any(m['selected_kind']==0) else np.zeros((1,32))
 p,prob=infer_cached(m,c[None,:],f,old)
 return {'version':'round3-numerical-v1','scope':'internal_synthetic_research_nine_development_responses','hardware_validated':False,'supports_unknown_real_device':False,'formal_report_eligible':False,'predicted_element_percent':dict(zip(m['elements'].tolist(),p[0].tolist())),'reported_percent':dict.fromkeys(m['elements'].tolist()),'response_hypothesis':{'candidate_id':ids[int(r[3])],'candidate_ids':ids,'deviance':r[4].tolist(),'relative_margin':r[5],'true_instrument_condition_identified':False,'ambiguous':bool(r[5]<.05)},'element_diagnostics':{e:{'branch':['frozen_round2','new_spectral_ridge','new_matrix_calibration'][int(m['selected_kind'][j])],'conditional_peak_snr':float(r[2][j]),'classifier_score':float(prob[0,j]),'classifier_score_is_calibrated_probability':False,'gate_threshold':float(m['selected_threshold'][j]),'point_zero_is_confirmed_absence':False,'below_10ppm_estimate':bool(p[0,j]<.001)} for j,e in enumerate(m['elements'].tolist())},'note':'All point estimates remain in accuracy denominators. Classifier scores, conditional SNR and 10ppm are not certified probability or LOD; fixed IRLS steps do not establish convergence or real-device calibration.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--input',required=True,type=pathlib.Path);p.add_argument('--out',required=True,type=pathlib.Path);a=p.parse_args()
 if a.out.exists():raise FileExistsError(a.out)
 result=predict(a.input)
 with a.out.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False)
