"""V6 development correction; original frozen V6 remains unchanged."""
import sys,json,pathlib
import numpy as np
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import runtime_v6 as base

def apply(rule,baseline,point=None,prob=None,hard=None):
    if rule['mode']=='baseline': return baseline.copy()
    if rule['mode']=='scale': return np.clip(baseline*rule['scale'],0,100)
    support=hard if rule['hard'] else np.ones(len(baseline),dtype=bool)
    candidate=np.where(support & (prob>=rule['threshold']),point*rule['scale'],0.)
    return np.clip((1-rule['alpha'])*baseline+rule['alpha']*candidate,0,100)

def infer(shared,extras,hard,baseline):
    selection=base.read(HERE/'selection.json');out=baseline.copy()
    for j,rule in enumerate(selection['rules']):
        if rule['mode']=='expert':
            weights=base.load(HERE.parent/f'stages/stage3/element_{j:02}.npz')
            prob,points=base.candidate(weights,np.c_[shared,extras[:,j]],hard[:,j])
            if rule.get('new_head'):
                w=base.load(HERE/f'heads/element_{j:02}.npz')
                value=np.exp(np.clip(base.head(w,'low_',np.c_[shared,extras[:,j]]),np.log(1e-12),np.log(100)))
                points=np.stack([value,value])
            out[:,j]=apply(rule,baseline[:,j],points[rule['head']],prob,hard[:,j])
        else:out[:,j]=apply(rule,baseline[:,j])
    return out

def predict(path):
    freeze=base.read(HERE/'freeze.json')
    for rel,digest in freeze['files'].items():
        if base.sha(HERE.parent/rel)!=digest:raise ValueError('Frozen dependency changed: '+rel)
    obj=base.read(path);c=base.old.anchor_runtime.base.blind_counts(obj)
    r=base.old.fit_one(c,base.old.load());f={k:np.array([v]) for k,v in r.items()}
    prev=base.old.anchor_runtime.base.previous_prediction(c)
    anchor=base.old.anchor_runtime.infer_cached(base.old.anchor_runtime.model('fusion_model.npz'),c[None,:],f,prev)[0]
    s,e,h=base.representation(c[None,:],f)
    b=base.infer_precomputed(base.read(HERE.parent/'selection.json'),s,e,h,anchor)
    p=infer(s,e,h,b)[0];names=base.read(HERE.parent/'selection.json')['element_names']
    return {'version':'V6-development-correction','formal_report_eligible':False,'hardware_validated':False,'predicted_element_percent':dict(zip(names,p.tolist())),'reported_percent':dict.fromkeys(names),'note':'Synthetic development correction; scoring zero is not proof of absence.'}

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--input',required=True);parser.add_argument('--out',required=True);args=parser.parse_args()
    with pathlib.Path(args.out).open('x',encoding='utf-8') as f:json.dump(predict(args.input),f,ensure_ascii=False,indent=2,allow_nan=False)
