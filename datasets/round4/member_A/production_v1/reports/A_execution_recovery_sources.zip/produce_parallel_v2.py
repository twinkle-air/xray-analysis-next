"""Two memory-gated fresh batch processes; adopt a live v1 batch on handoff."""
from __future__ import annotations
import argparse, ctypes, datetime, importlib.util, json, os, pathlib, subprocess, sys, time
from ctypes import wintypes

HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('recovery_base',HERE/'recover_isolated.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
REC=HERE/'parallel_v2';STATE=REC/'state.json';GIB=1024**3

class MemoryStatus(ctypes.Structure):
    _fields_=[('length',wintypes.DWORD),('load',wintypes.DWORD),('total_phys',ctypes.c_ulonglong),('avail_phys',ctypes.c_ulonglong),('total_page',ctypes.c_ulonglong),('avail_page',ctypes.c_ulonglong),('total_virtual',ctypes.c_ulonglong),('avail_virtual',ctypes.c_ulonglong),('avail_extended',ctypes.c_ulonglong)]
def memory():
    m=MemoryStatus();m.length=ctypes.sizeof(m)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise ctypes.WinError()
    return {'available_physical_bytes':m.avail_phys,'available_commit_bytes':m.avail_page,'memory_load_percent':m.load}
def allow_launch(active,m):
    # Keep headroom for one complete generation/replay lifetime, not just startup.
    return active<2 and m['available_physical_bytes']>=2.5*GIB and m['available_commit_bytes']>=5*GIB
def now():return base.now()
def write(p,d):base.write(p,d)
def read(p):return base.read(p)

class Adopted:
    def __init__(self,pid):
        self.pid=pid;self.returncode=None
        k=ctypes.windll.kernel32
        k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
        k.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)]
        k.CloseHandle.argtypes=[wintypes.HANDLE]
        self.handle=k.OpenProcess(0x100000|0x1000,False,pid)
        if not self.handle:raise ctypes.WinError()
    def poll(self):
        if self.returncode is not None:return self.returncode
        code=wintypes.DWORD()
        if not ctypes.windll.kernel32.GetExitCodeProcess(self.handle,ctypes.byref(code)):raise ctypes.WinError()
        if code.value!=259:
            self.returncode=code.value;ctypes.windll.kernel32.CloseHandle(self.handle)
        return self.returncode

def child(bid):
    # This changes only the external receipt location; numerical APIs are original.
    base.REC=REC;base.child(bid)

def supervise(handoff_path):
    if STATE.exists():raise FileExistsError('Parallel state exists; inspect before restart')
    handoff=read(handoff_path);plan=base.batches();valid_ids={b['batch_id'] for b in plan}
    adopted=handoff.get('adopted_batch_id');pid=handoff.get('adopted_pid')
    if adopted and adopted not in valid_ids:raise ValueError('Unknown adopted batch')
    active={};results={};failed=[];pending=[]
    state={'status':'validating_handoff','started_at_utc':now(),'supervisor_pid':os.getpid(),'max_workers':2,'isolation':'fresh_process_per_batch','physical_launch_reserve_GiB':2.5,'commit_launch_reserve_GiB':5,'handoff':handoff,'code_sha256':base.digest(pathlib.Path(__file__))}
    write(STATE,state)
    try:
        if adopted and pid:active[adopted]={'process':Adopted(pid),'adopted':True,'started_at_utc':handoff['at_utc'],'streams':[]}
        r=base.runner();r.worker_init(str(base.REPO),str(base.FREEZE),str(base.RELEASE),'A',str(base.OUT),10)
        write(REC/'preflight.json',r.dry_run(base.REPO,base.FREEZE,base.RELEASE,'A'))
        for b in plan:
            bid=b['batch_id']
            if bid in active:continue
            summary=base.OUT/'reports'/bid/'summary.json'
            if summary.exists():
                # The frozen resume verifier checks archive hash/CRC and full QC evidence.
                results[bid]=r.run_batch(b)
            else:
                artifacts=[base.OUT/'sealed_batches'/bid,base.OUT/'reports'/bid,base.OUT/'archives'/(bid+'.zip')]
                if any(p.exists() for p in artifacts):raise ValueError('Unowned partial batch retained: '+bid)
                pending.append(b)
        write(REC/'resume_verified.json',{'batches':len(results),'records':sum(x['records'] for x in results.values()),'freeze_manifest_sha256':base.digest(base.FREEZE/'freeze_manifest.json'),'original_runner_sha256':base.digest(base.TOOLS/'run_member.py')})
        while active or pending:
            for bid,entry in list(active.items()):
                code=entry['process'].poll()
                if code is None:continue
                for stream in entry['streams']:stream.close()
                summary=base.OUT/'reports'/bid/'summary.json'
                if code!=0 or not summary.exists():
                    failed.append({'batch_id':bid,'exit_code':code,'partial_preserved':True})
                else:
                    try:results[bid]=r.run_batch(next(b for b in plan if b['batch_id']==bid))
                    except BaseException as exc:failed.append({'batch_id':bid,'error':str(exc),'partial_preserved':True})
                del active[bid]
            mem=memory()
            if pending and not failed and allow_launch(len(active),mem):
                b=pending.pop(0);bid=b['batch_id'];log=REC/'logs'/bid;log.parent.mkdir(parents=True,exist_ok=True)
                so=log.with_suffix('.stdout.log').open('wb');se=log.with_suffix('.stderr.log').open('wb')
                try:
                    proc=subprocess.Popen([sys.executable,'-B','-u',str(pathlib.Path(__file__).resolve()),'--batch',bid],cwd=base.ROOT,stdout=so,stderr=se,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
                except BaseException:
                    so.close();se.close();raise
                active[bid]={'process':proc,'adopted':False,'started_at_utc':now(),'streams':[so,se]}
            state.update(status='draining_after_failure' if failed else 'running',updated_at_utc=now(),passed_batches=len(results),passed_records=sum(x['records'] for x in results.values()),pending_batches=len(pending),active_batches=[{'batch_id':bid,'pid':e['process'].pid,'adopted':e['adopted'],'started_at_utc':e['started_at_utc']} for bid,e in active.items()],failures=failed,memory=mem)
            write(STATE,state)
            if failed and not active:raise RuntimeError('Batch failure; stopped new launches and preserved all data')
            time.sleep(2)
        if len(results)!=400 or sum(x['records'] for x in results.values())!=40000:raise ValueError('Incomplete batch coverage')
        state.update(status='finalizing',updated_at_utc=now());write(STATE,state)
        command=[sys.executable,'-B','-u',str(base.TOOLS/'run_member.py'),'--repository',str(base.REPO),'--freeze',str(base.FREEZE),'--release',str(base.RELEASE),'--member','A','--out',str(base.OUT),'--workers','1','--minimum-free-gib','10','--include-sealed-qc']
        with (REC/'finalize.stdout.log').open('wb') as so,(REC/'finalize.stderr.log').open('wb') as se:subprocess.run(command,cwd=base.ROOT,stdout=so,stderr=se,check=True)
        summary=read(base.OUT/'selfcheck_summary.json')
        if summary.get('actual_records')!=40000 or summary.get('packaging_status')!='complete':raise ValueError('Incomplete final delivery')
        state.update(status='complete_pending_coordinator_acceptance',finished_at_utc=now(),summary=summary);write(STATE,state)
    except BaseException as exc:
        state.update(status='failed_partial_preserved',updated_at_utc=now(),error_type=type(exc).__name__,error=str(exc),active_batches=[{'batch_id':bid,'pid':e['process'].pid} for bid,e in active.items()]);write(STATE,state);raise

if __name__=='__main__':
    os.environ.update(PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    p=argparse.ArgumentParser();p.add_argument('--batch');p.add_argument('--handoff',type=pathlib.Path);args=p.parse_args()
    if args.batch:child(args.batch)
    elif args.handoff:supervise(args.handoff)
    else:p.error('--batch or --handoff required')
