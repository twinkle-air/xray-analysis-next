# XRF V9 / V10 冻结运行包

本包供数值研究与智能体后端接入。没有重新训练；V9为当前联合强度定量＋谱支持诊断版本，V10为完整分类＋定量增量版本。两版必须保留包内的共享依赖目录结构，不需要独立V6模型目录。

## 安装与运行

建议使用Python 3.12，先创建独立环境，再在本README所在目录运行：

```powershell
python -m pip install -r requirements.txt
python -B verify_package.py --smoke
python -B run_model.py --model V10 --input examples/synthetic_blind.json --out v10_result.json
python -B run_model.py --model V9 --input examples/synthetic_blind.json --out v9_result.json
```

输出文件必须不存在。`run_model.py`以独立子进程运行冻结入口，成功解析结果后才发布输出，失败清理暂存文件；不修改模型算式。原始入口可能在失败时留下空文件，接入时应使用此包装器。不要在同一解释器中反复切换不同运行包。

## 输入与输出

输入JSON必须恰有五个字段：`axis="channel"`、`signal_unit="counts"`、`synthetic=true`、`x=[0,…,2047]`、长度2048的非负整数`counts`；总计数必须大于0。不允许加入配方、标签、仪器参数或随机种子。

`synthetic=true`是当前能力边界，不能将实测数据改标为合成谱以绕过检查。实测谱解析、通道映射和仪器适用性需要后续单独验证。

输出`predicted_element_percent`为32个目标元素的质量百分含量估计。1%=10,000 ppm。输出0表示模型按现有规则未报出，不能证明元素不存在。V10的分类概率不是含量准确率；V9的谱支持诊断不是准确性保证。当前两版均有`formal_report_eligible=false`、`hardware_validated=false`。

元素：Na、Mg、Al、Si、P、S、Cl、K、Ca、Ti、V、Cr、Mn、Fe、Co、Ni、Cu、Zn、As、Se、Rb、Sr、Y、Zr、Nb、Mo、Cd、Sn、Sb、Ba、W、Pb。氧及其他未建模基体不能凭此结果补算，也不应强制归一化到100%。

## 版本职责与证据

智能体方案推荐V10为主推断，V9作可选差异参考。V9在旧域部分定量指标仍占优；不得把“两版一致”解释为正确，不得自动取均值、逐元素挑选或无验证地切换版本。

随包`source_manifest.json`记录来源文件哈希和移植改动；V10只修改依赖路径解析及相应哈希，不改算法和权重。`integrity.json`覆盖包中其余文件，外部ZIP另有SHA-256。`examples/expected_*.json`仅为工程回归输出，不是标准样品真值。完整测试边界及结果见协作仓库本目录旁的`evidence/`及`docs/agent-construction-v1/`。

包内出现`runtime_v6.py`等历史名称，是V9/V10必须调用的内部组件，不构成可单独发布的V6版本。删除这些文件会破坏当前模型。
