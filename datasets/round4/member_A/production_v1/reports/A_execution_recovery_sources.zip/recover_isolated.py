"""A recovery attempt: unchanged frozen producer, one fresh process per batch.

Incomplete artifacts are quarantined, never overwritten. Stop on the first error.
No numerical code, input, seed, QC threshold, or sealed role is modified.
"""
from __future__ import annotations
import argparse, datetime, hashlib, json, os, pathlib, subprocess, sys, time

HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parents[1]
REPO=ROOT/'outputs/round4-global-freeze-20261025/snapshot'
FREEZE=REPO/'datasets/round4/shared/freeze_v1'
RELEASE=REPO/'datasets/round4/shared/releases/production_release_v1.json'
TOOLS=REPO/'datasets/round4/shared/production_tools'
OUT=ROOT/'outputs/round4-A-production-20261025'
REC=HERE/'recovery_v1'
STATE=REC/'state.json'

def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,data):
    p.parent.mkdir(parents=True,exist_ok=True)
    q=p.with_suffix('.writing');q.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');q.replace(p)
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def runner():
    sys.path.insert(0,str(TOOLS))
    import run_member
    return run_member
def batches():return [b for b in read(FREEZE/'batch_plan.json')['batches'] if b['member']=='A']
def child(bid):
    r=runner();r.worker_init(str(REPO),str(FREEZE),str(RELEASE),'A',str(OUT),10)
    batch=next(b for b in batches() if b['batch_id']==bid)
    result=r.run_batch(batch)
    write(REC/'verified_batches'/(bid+'.json'),result)
    print(json.dumps({'batch_id':bid,'status':result['status'],'records':result['records']}),flush=True)

def prepare():
    # Validate release and all 40,000 planned records before touching partials.
    r=runner();r.validate_freeze(REPO,FREEZE,RELEASE,'A',production=True,include_sealed=True)
    report=r.dry_run(REPO,FREEZE,RELEASE,'A');write(REC/'preflight.json',report)
    if (REC/'quarantine_inventory.json').exists():return
    valid=[];moves=[]
    for b in batches():
        bid=b['batch_id'];s=OUT/'reports'/bid/'summary.json'
        if s.exists() and read(s).get('status')=='passed_all_records':
            valid.append({'batch_id':bid,'summary_sha256':digest(s),'archive_sha256':digest(OUT/'archives'/(bid+'.zip'))})
            continue
        for rel in [pathlib.Path('sealed_batches')/bid,pathlib.Path('reports')/bid,pathlib.Path('archives')/(bid+'.zip'),pathlib.Path('archives')/(bid+'.zip.sha256')]:
            src=(OUT/rel).resolve();dst=(REC/'quarantine'/rel).resolve()
            if not src.is_relative_to(OUT.resolve()) or not dst.is_relative_to((REC/'quarantine').resolve()):raise ValueError('Unsafe recovery path')
            if src.exists():
                files=[src] if src.is_file() else sorted(p for p in src.rglob('*') if p.is_file())
                moves.append({'relative_path':rel.as_posix(),'files':[{'path':p.relative_to(OUT).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)} for p in files]})
    write(REC/'quarantine_inventory_planned.json',{'preserved_passed_batches':valid,'moves':moves})
    for move in moves:
        rel=pathlib.Path(move['relative_path']);src=OUT/rel;dst=REC/'quarantine'/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        if dst.exists():raise FileExistsError(dst)
        src.rename(dst)
        for f in move['files']:
            p=REC/'quarantine'/f['path']
            if p.stat().st_size!=f['bytes'] or digest(p)!=f['sha256']:raise ValueError('Quarantine preservation mismatch')
    for v in valid:
        if digest(OUT/'reports'/v['batch_id']/'summary.json')!=v['summary_sha256'] or digest(OUT/'archives'/(v['batch_id']+'.zip'))!=v['archive_sha256']:raise ValueError('Completed batch changed')
    write(REC/'quarantine_inventory.json',{'status':'verified_lossless_moves','preserved_passed_batches':valid,'moves':moves})

def supervise():
    if STATE.exists():raise FileExistsError('Inspect existing recovery before launching another supervisor')
    REC.mkdir(parents=True,exist_ok=True)
    state={'status':'preparing','started_at_utc':now(),'workers':1,'isolation':'fresh_process_per_batch','supervisor_pid':os.getpid(),'freeze_manifest_sha256':digest(FREEZE/'freeze_manifest.json'),'original_runner_sha256':digest(TOOLS/'run_member.py'),'code_sha256':digest(pathlib.Path(__file__))}
    write(STATE,state)
    try:
        prepare();plan=batches()
        # Verify existing successes first; subsequent children generate missing batches.
        plan.sort(key=lambda b:not (OUT/'reports'/b['batch_id']/'summary.json').exists())
        for i,b in enumerate(plan):
            bid=b['batch_id'];was_complete=(OUT/'reports'/bid/'summary.json').exists()
            state.update(status='running',batch_id=bid,batch_action='verify_resume' if was_complete else 'generate_full_QC',validated_batches_this_attempt=i,updated_at_utc=now())
            log=REC/'logs'/bid;log.parent.mkdir(parents=True,exist_ok=True)
            with log.with_suffix('.stdout.log').open('wb') as so,log.with_suffix('.stderr.log').open('wb') as se:
                childproc=subprocess.Popen([sys.executable,'-B','-u',str(pathlib.Path(__file__).resolve()),'--batch',bid],cwd=ROOT,stdout=so,stderr=se,stdin=subprocess.DEVNULL)
                state['child_pid']=childproc.pid;write(STATE,state)
                while childproc.poll() is None:
                    state['updated_at_utc']=now();write(STATE,state);time.sleep(10)
                if childproc.returncode:raise RuntimeError(f'{bid} exited {childproc.returncode}; partials preserved, no automatic retry')
            state.update(validated_batches_this_attempt=i+1,updated_at_utc=now());write(STATE,state)
        # Original finalizer revalidates every archived batch before aggregating.
        state.update(status='finalizing',updated_at_utc=now());write(STATE,state)
        command=[sys.executable,'-B','-u',str(TOOLS/'run_member.py'),'--repository',str(REPO),'--freeze',str(FREEZE),'--release',str(RELEASE),'--member','A','--out',str(OUT),'--workers','1','--minimum-free-gib','10','--include-sealed-qc']
        with (REC/'finalize.stdout.log').open('wb') as so,(REC/'finalize.stderr.log').open('wb') as se:
            subprocess.run(command,cwd=ROOT,stdout=so,stderr=se,check=True)
        summary=read(OUT/'selfcheck_summary.json')
        if summary.get('actual_records')!=40000 or summary.get('packaging_status')!='complete':raise ValueError('Incomplete final delivery')
        state.update(status='complete_pending_coordinator_acceptance',finished_at_utc=now(),summary=summary);write(STATE,state)
    except BaseException as exc:
        state.update(status='failed_partial_preserved',updated_at_utc=now(),error_type=type(exc).__name__,error=str(exc));write(STATE,state);raise

if __name__=='__main__':
    os.environ.update(PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    p=argparse.ArgumentParser();p.add_argument('--batch');p.add_argument('--check',action='store_true');args=p.parse_args()
    if args.check:
        r=runner();r.validate_freeze(REPO,FREEZE,RELEASE,'A',production=True,include_sealed=True)
        print(json.dumps(r.dry_run(REPO,FREEZE,RELEASE,'A')))
    elif args.batch:child(args.batch)
    else:supervise()
