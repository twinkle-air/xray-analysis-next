"""Joint-spectrum decomposition + train-only matrix calibration + frozen baseline fallback."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ.setdefault(k,'1')
import json,argparse
from pathlib import Path
import numpy as np
from peak_fit_old import fit_one,load_dictionary
from baseline_model import counts_from_blind,infer_arrays as baseline_infer
HERE=Path(__file__).resolve().parent
MAJOR_INDICES=np.array([0,1,2,3,4,5,6,7,8,9,12,13])

def matrix_raw(amplitudes,totals,continuum):
    return np.c_[np.sqrt(np.maximum(amplitudes[:,MAJOR_INDICES],0)/totals[:,None]),np.log1p(totals),continuum]
def polynomial(x,degree):
    if degree==1:return np.c_[np.ones(len(x)),x]
    a,b=np.triu_indices(x.shape[1]);return np.c_[np.ones(len(x)),x,x[:,a]*x[:,b]]
def base_model(m):return {k[5:]:m[k] for k in m.keys() if k.startswith('base_')}
def infer_cached(m,counts,amp,snr,hypothesis,continuum):
    counts=np.atleast_2d(counts);total=counts.sum(axis=1);raw=matrix_raw(amp,total,continuum)
    old=baseline_infer(base_model(m),counts);pred=old.copy()
    for j in range(32):
        if int(m['selected_degree'][j])==0:continue
        degree=int(m['selected_degree'][j]);alpha_index=int(m['selected_alpha_index'][j]);out=np.zeros(len(counts))
        for h in range(m['matrix_mean'].shape[0]):
            mask=hypothesis==h
            if not mask.any():continue
            x=(raw[mask]-m['matrix_mean'][h])/m['matrix_scale'][h];design=polynomial(x,degree)
            coef=m[f'cal_{degree}_{alpha_index}'][h,:,j]
            factor=np.clip(design@coef,m[f'lo_{degree}_{alpha_index}'][h,j],m[f'hi_{degree}_{alpha_index}'][h,j])
            out[mask]=amp[mask,j]/total[mask]*np.exp(factor)
        out[snr[:,j]<m['selected_snr_cut'][j]]=0
        blend=float(m['selected_blend'][j]);pred[:,j]=blend*out+(1-blend)*old[:,j]
    return np.clip(pred,0,100),old
def extract_counts(counts,dictionary):
    r=[fit_one(c,dictionary) for c in np.atleast_2d(counts)]
    return {'amplitudes':np.array([x[0] for x in r]),'errors':np.array([x[1] for x in r]),'snr':np.array([x[2] for x in r]),'hypothesis':np.array([x[3] for x in r]),'deviance':np.array([x[4] for x in r]),'hypothesis_margin':np.array([x[5] for x in r]),'continuum_fraction':np.array([x[6] for x in r])}
def predict(model_path,input_path):
    blind=json.loads(Path(input_path).read_text(encoding='utf-8-sig'));counts=counts_from_blind(blind)
    with np.load(model_path,allow_pickle=False) as m:
        dictionary=[(m[f'design_{i}'],m[f'owners_{i}']) for i in range(m['matrix_mean'].shape[0])];f=extract_counts(counts,dictionary)
        p,_=infer_cached(m,counts,f['amplitudes'],f['snr'],f['hypothesis'],f['continuum_fraction'])
        flags={str(e):{'conditional_peak_snr':float(f['snr'][0,j]),'low_peak_information':bool(f['snr'][0,j]<3),'below_10ppm_estimate':bool(p[0,j]<.001),'not_a_detection_claim':True} for j,e in enumerate(m['elements'])}
        return {'scope':'synthetic_three_candidate_response_internal_research','hardware_validated':False,'supports_unknown_real_device':False,'predicted_element_percent':dict(zip(m['elements'].tolist(),p[0].tolist())),'element_diagnostics':flags,'response_hypothesis':{'candidate':int(f['hypothesis'][0])+1,'true_instrument_condition_identified':False,'deviance':f['deviance'][0].tolist(),'relative_margin':float(f['hypothesis_margin'][0]),'ambiguous':bool(f['hypothesis_margin'][0]<.05)},'note':'No true calibration/profile metadata used from query. Conditional SNR and candidate ambiguity are model-dependent heuristics, not certified LOD, physical uniqueness or uncertainty coverage. Low-information results remain in evaluation.'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',type=Path,default=HERE/'physics_model.npz');p.add_argument('--input',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    answer=predict(a.model,a.input)
    with a.out.open('x',encoding='utf8') as f:json.dump(answer,f,ensure_ascii=False,indent=2,allow_nan=False)
