"""Explicit response roles, model dimensions and cache producer identities."""
import hashlib
import json
import re
from pathlib import Path
import numpy as np
VARIANT_IDS = ('irls_reference', 'poisson_reference', 'poisson_matrix_update')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def response_count(model):
    ids = sorted(int(match.group(1)) for key in model for match in [re.fullmatch(r'design_(\d+)', key)] if match)
    if not ids or ids != list(range(len(ids))):
        raise ValueError('Response matrices must be contiguous from zero')
    return len(ids)

def verify_source_manifest(root,names):
    root=Path(root)
    files=json.loads((root/'delivery_manifest.json').read_text(encoding='utf8'))['files']
    for name in names:
        if name not in files or sha(root/name)!=files[name]['sha256']:
            raise ValueError('Source artifact is not its sealed identity: '+name)

def require_same_hash(path,expected):
    if sha(path)!=expected:raise ValueError('Frozen hash mismatch: '+str(path))

def validate_dictionary_identity(dictionary,registry):
    ids=[e['id'] for e in registry['responses']]
    hashes=[e['profile_sha256'] for e in registry['responses']]
    if 'response_ids' not in dictionary or 'response_profile_sha256' not in dictionary:
        raise ValueError('Dictionary lacks profile identity metadata; explicit migration/rebuild required')
    if dictionary['response_ids'].tolist()!=ids or dictionary['response_profile_sha256'].tolist()!=hashes:
        raise ValueError('Dictionary/profile identity or order differs')
    if response_count(dictionary)!=len(ids):raise ValueError('Dictionary response count differs')

def validate_registry(registry, root, model=None):
    entries = registry['responses']; ids = [e['id'] for e in entries]
    if not ids or len(ids) != len(set(ids)):
        raise ValueError('Empty/duplicate response IDs')
    if tuple(registry['variant_ids']) != VARIANT_IDS:
        raise ValueError('Fitting variants differ from response conditions')
    hashes = []; root = Path(root).resolve()
    for e in entries:
        if e['role'] != 'development' or e['id'] in registry.get('forbidden_response_ids', []):
            raise ValueError('Held-out response forbidden in development dictionary')
        p = (root/e['profile_path']).resolve()
        if not p.is_relative_to(root):
            raise ValueError('Profile path escapes version directory')
        actual = sha(p)
        if actual != e['profile_sha256'] or actual in registry.get('forbidden_profile_sha256', []):
            raise ValueError('Profile hash/role mismatch')
        hashes.append(actual)
    if len(hashes) != len(set(hashes)):
        raise ValueError('Duplicate profile identity')
    if model is not None:
        n = response_count(model)
        if len(entries) != n or model['cal_mean'].shape[1] != n or model['cal_coeff'].shape[1] != n:
            raise ValueError('Response calibration mismatch; refit required')
        if model['cal_mean'].shape[0] != len(VARIANT_IDS):
            raise ValueError('Variant dimensions mismatch')
        prior = {k[6:]: v for k, v in model.items() if k.startswith('prior_')}
        if response_count(prior) != n or prior['matrix_mean'].shape[0] != n:
            raise ValueError('Prior response calibrations must be refitted too')
        if model['response_ids'].tolist() != ids or model['response_profile_sha256'].tolist() != hashes:
            raise ValueError('Model/profile identity or order mismatch')
        if len(model['elements']) != 32 or len(set(model['elements'].tolist())) != 32:
            raise ValueError('32 unique elements required')
        if not np.array_equal(prior['elements'],model['elements']):raise ValueError('Prior element order differs')
        for key in prior:
            if re.fullmatch(r'(cal|lo|hi)_\d+_\d+',key) and prior[key].shape[0]!=n:
                raise ValueError('Prior calibration tensor does not cover all responses')
        for h in range(n):
            for prefix in ('', 'prior_'):
                a, owner = model[f'{prefix}design_{h}'], model[f'{prefix}owners_{h}']
                if a.ndim != 2 or a.shape[0] != 1024 or a.shape[1] != len(owner):
                    raise ValueError('Response matrix/owner shape mismatch')
                if not np.isfinite(a).all() or (a < 0).any():
                    raise ValueError('Invalid response matrix')
            for key in ('cal_mean','cal_scale','cal_coeff','cal_low','cal_high'):
                if model[key].shape[1]!=n or not np.isfinite(model[key][:,h]).all():
                    raise ValueError('Nonfinite/misaligned calibration condition')
            if (model['cal_scale'][:,h]<=0).any():raise ValueError('Nonpositive calibration scale')
    return ids

def validate_indices(indices, rows, splits):
    raw = np.asarray(indices)
    if raw.ndim != 1 or not np.issubdtype(raw.dtype, np.integer):
        raise ValueError('Indices must be a one-dimensional integer array')
    if (raw < 0).any() or (raw >= len(rows)).any():
        raise ValueError('Cache index out of bounds')
    if len(set(raw.tolist())) != len(raw):
        raise ValueError('Duplicate cache indices')
    expected = np.array([i for i, row in enumerate(rows) if row['split'] in splits])
    if not np.array_equal(raw, expected):
        raise ValueError('Exact authoritative coverage in canonical order required')
    return raw

def seal_cache(path, identities):
    path = Path(path)
    record = {'schema_version': 1, 'cache_sha256': sha(path), 'identities': {k: sha(v) for k, v in identities.items()}}
    with path.with_suffix('.identity.json').open('x', encoding='utf8') as f:
        json.dump(record, f, indent=2)

def load_cache(path, identities, rows, splits, variants=3):
    path = Path(path)
    record = json.loads(path.with_suffix('.identity.json').read_text(encoding='utf8'))
    if record['cache_sha256'] != sha(path):
        raise ValueError('Cache content hash mismatch')
    if record['identities'] != {k: sha(v) for k, v in identities.items()}:
        raise ValueError('Cache producer/source identity mismatch')
    with np.load(path, allow_pickle=False) as z:
        f = {k: z[k].copy() for k in z.files}
    ii = validate_indices(f['indices'], rows, splits)
    for k in ('amplitudes', 'errors', 'snr', 'shell', 'null_delta', 'deviance', 'continuum_fraction'):
        if f[k].shape[:2] != (variants, len(ii)) or not np.isfinite(f[k]).all():
            raise ValueError('Cache shape/nonfinite: '+k)
    for k in ('prior_prediction', 'baseline_prediction', 'hypothesis'):
        if len(f[k]) != len(ii) or not np.isfinite(f[k]).all():
            raise ValueError('Cache row/nonfinite: '+k)
    if f['prior_prediction'].shape != (len(ii),32) or f['baseline_prediction'].shape != (len(ii),32):
        raise ValueError('Prediction dimensions mismatch')
    expected_shapes={'amplitudes':(variants,len(ii),32),'errors':(variants,len(ii),32),
        'snr':(variants,len(ii),32),'shell':(variants,len(ii),32,3),
        'null_delta':(variants,len(ii),32),'deviance':(variants,len(ii)),
        'continuum_fraction':(variants,len(ii))}
    for key,shape in expected_shapes.items():
        if f[key].shape!=shape:raise ValueError('Wrong exact cache shape: '+key)
    if f['hypothesis'].shape!=(len(ii),) or not np.issubdtype(f['hypothesis'].dtype,np.integer):
        raise ValueError('Response indices must be integers')
    registry=json.loads(Path(identities['response_registry']).read_text(encoding='utf8'))
    if (f['hypothesis']<0).any() or (f['hypothesis']>=len(registry['responses'])).any():
        raise ValueError('Cache contains unknown response')
    return f
