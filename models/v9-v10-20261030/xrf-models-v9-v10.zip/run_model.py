"""Isolated, failure-clean wrapper; frozen model arithmetic is unchanged."""
import argparse,pathlib,tempfile,subprocess,sys,json,os
H=pathlib.Path(__file__).resolve().parent
ENTRIES={'V9':'model-v9-20261028/domain_guard/domain_runtime.py','V10':'model-v10-20261030/runtime_v10.py'}
def main():
    p=argparse.ArgumentParser();p.add_argument('--model',required=True,choices=ENTRIES);p.add_argument('--input',required=True,type=pathlib.Path);p.add_argument('--out',required=True,type=pathlib.Path);a=p.parse_args();inp=a.input.resolve(strict=True);out=a.out.resolve()
    if out.exists():raise FileExistsError('Refusing to overwrite output')
    with tempfile.TemporaryDirectory(prefix='.xrf-job-',dir=out.parent) as td:
        staged=pathlib.Path(td)/'result.json';env=dict(os.environ,PYTHONIOENCODING='utf-8');child=subprocess.run([sys.executable,'-B',str(H/'outputs'/ENTRIES[a.model]),'--input',str(inp),'--out',str(staged)],capture_output=True,text=True,encoding='utf-8',errors='replace',env=env)
        if child.returncode:raise RuntimeError('Model execution failed; no result published.\n'+child.stderr[-4000:])
        obj=json.loads(staged.read_text(encoding='utf-8'));assert obj['version']==a.model and isinstance(obj['predicted_element_percent'],dict)
        with out.open('x',encoding='utf-8') as f:json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False)
if __name__=='__main__':main()
