"""Count-only Round4 candidate: learned presence and nonlinear concentrations."""
from __future__ import annotations
import argparse,hashlib,json,pathlib,sys
import numpy as np
from scipy.special import expit
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'anchor'))
import runtime_v5 as old

def read(p):return json.loads(pathlib.Path(p).read_text(encoding='utf-8-sig'))
def sha(p):
    with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def representation(counts,f):
    c=np.atleast_2d(counts);s=old.shared_features(c,f)
    extra=np.stack([old.element_features(s,c,f,j)[:,-6:] for j in range(32)],axis=1)
    hard=(f['amplitudes']>0)&(f['snr']>=.5)&(f['null_delta']>0)
    return s.astype(np.float32),extra.astype(np.float32),hard
def head(weights,prefix,x):
    out=np.full(len(x),float(weights[prefix+'baseline'][0]));offset=weights[prefix+'offsets'];nodes=weights[prefix+'nodes']
    for a,b in zip(offset[:-1],offset[1:]):out+=old.tree_prediction(nodes[int(a):int(b)],x)
    return out
def candidate(weights,x,hard):
    probability=expit(head(weights,'presence_',x))
    logpoint=np.exp(np.clip(head(weights,'log_',x),np.log(1e-12),np.log(100)))
    linear=np.clip(head(weights,'linear_',x),0,100)
    return probability,np.stack([logpoint,linear])
def combine(anchor,point,probability,hard,threshold,alpha):
    if not 0<=alpha<=1 or not 0<=threshold<=1:raise ValueError('Invalid candidate rule')
    admitted=hard&(probability>=threshold)
    candidate_point=np.where(admitted,point,0.)
    out=np.clip((1-alpha)*anchor+alpha*candidate_point,0,100)
    if not np.isfinite(out).all():raise ValueError('Non-finite prediction')
    return out
def infer_precomputed(selection,shared,extras,hard,anchor):
    answer=np.array(anchor,copy=True);cache={}
    for j,choice in enumerate(selection['elements']):
        if choice['stage']==0:continue
        key=(choice['stage'],j)
        if key not in cache:cache[key]=load(HERE/f"stages/stage{choice['stage']}/element_{j:02}.npz")
        x=np.c_[shared,extras[:,j]];prob,points=candidate(cache[key],x,hard[:,j])
        answer[:,j]=combine(anchor[:,j],points[choice['head']],prob,hard[:,j],choice['threshold'],choice['alpha'])
    return answer
def predict(path):
    freeze=read(HERE/'selection_freeze.json')
    for rel,digest in freeze['runtime_sha256'].items():
        if sha(HERE/rel)!=digest:raise ValueError('Frozen candidate changed: '+rel)
    obj=read(path);c=old.anchor_runtime.base.blind_counts(obj)
    r=old.fit_one(c,old.load());f={k:np.array([v]) for k,v in r.items()};previous=old.anchor_runtime.base.previous_prediction(c)
    anchor=old.anchor_runtime.infer_cached(old.anchor_runtime.model('fusion_model.npz'),c[None,:],f,previous)[0]
    shared,extras,hard=representation(c[None,:],f);selection=read(HERE/'selection.json');point=infer_precomputed(selection,shared,extras,hard,anchor)
    return {'version':'v6-round4-staged-research-candidate','scope':'synthetic_numerical_research','formal_report_eligible':False,'hardware_validated':False,'predicted_element_percent':dict(zip(selection['element_names'],point[0].tolist())),'reported_percent':dict.fromkeys(selection['element_names']),'note':'Validation-selected synthetic model. Scoring zeros are not confirmed absence. No Round4 sealed spectra or labels were used for fitting or selection; true-device accuracy is unverified.'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--out',required=True);a=p.parse_args();dest=pathlib.Path(a.out)
    if dest.exists():raise FileExistsError(dest)
    dest.write_text(json.dumps(predict(a.input),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
