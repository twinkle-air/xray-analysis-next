"""Check exact equivalence and bounded behavior on existing production records."""
import pathlib,sys,time,json,importlib.util,os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
HERE=pathlib.Path(__file__).resolve().parent
import recover_isolated as base
sys.path.insert(0,str(base.FREEZE/'generator'))
import numpy as np
from fp_competition import core
from exact_kernel_cache import ExactKernelCache

def encode(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def main():
    original=core._kernel_primitive;cache=ExactKernelCache(original,9000)
    t=np.array([[-.1,0,.3],[.2,-.4,.5]],dtype=np.float64)
    cases=[(t,1.),(t.copy(),1.),(t,np.nextafter(1.,2.)),(t+1e-12,1.),(t.astype(np.float32),1.),(t.reshape(3,2),1.)]
    for a,mu in cases:
        assert cache(a,mu).tobytes()==original(a,mu).tobytes()
    y=cache(t,1.);y[:]=99;assert cache(t,1.).tobytes()==original(t,1.).tobytes()
    for mu in np.linspace(.1,100,100):cache(t,float(mu));assert cache.bytes+cache.grid_bytes<=cache.limit
    assert cache.evictions>0
    cache.clear();assert cache.bytes==cache.grid_bytes==len(cache.items)==len(cache.grids)==0
    records=[]
    for bid in ('R4_A_train_stage3_development_0055','R4_A_train_stage3_development_0113'):
        for n in (1,2,3,4):
            p=base.OUT/'sealed_batches'/bid/'full_results'/f'S{n:06d}.json'
            records.append(base.read(p))
    def calculate(saved):return core.simulate(saved['composition']['original_percent'],core.Profile.from_dict(saved['profile']),seed=saved['seed'],closure=saved['composition']['closure_policy'],legacy_al=saved['composition']['legacy_al_policy'])
    # Warm original xraylib lookup caches equally for both timing runs.
    for saved in records[::4]:calculate(saved)
    start=time.perf_counter();baseline=[calculate(s) for s in records];baseline_seconds=time.perf_counter()-start
    cached=ExactKernelCache(original);core._kernel_primitive=cached
    try:
        start=time.perf_counter();optimized=[calculate(s) for s in records];optimized_seconds=time.perf_counter()-start
        for saved,a,b in zip(records,baseline,optimized):
            assert encode(a)==encode(b),'Full result changed'
            for k in ('counts','expected_counts','components_expected_counts','outside_window_counts','detected_signal_before_window_counts','lines'):
                assert encode(a[k])==encode(saved[k]),'Existing production record changed: '+k
    finally:core._kernel_primitive=original
    # Verify the replay entry explicitly empties generation cache without running a pilot.
    from fp_competition import dataset
    old_replay=dataset.replay_dataset;calls=[]
    def probe(*args,**kwargs):calls.append(len(installed.items));return {'probe':True}
    dataset.replay_dataset=probe
    from exact_kernel_cache import install
    installed,boundaries=install();installed(t,1.);assert installed.items
    dataset.replay_dataset(None);assert calls==[0] and boundaries[0]['entries_at_independent_replay_start']==0
    core._kernel_primitive=original;dataset.replay_dataset=old_replay
    report={'status':'passed','records_compared':len(records),'comparison':'byte-identical canonical JSON for every complete simulation result; arrays, counts, lines, window totals also match existing production records','baseline_seconds':baseline_seconds,'cached_seconds':optimized_seconds,'measured_speedup_small_sample':baseline_seconds/optimized_seconds,'cache_stats':cached.stats(),'mutation_eviction_input_bit_tests':'passed','independent_replay_cache_reset':'passed','physics_core_sha256':base.digest(base.FREEZE/'generator/fp_competition/core.py'),'adapter_sha256':base.digest(HERE/'exact_kernel_cache.py'),'limit':'Small existing-record timing test, not full-production throughput proof'}
    base.write(HERE/'parallel_v4/exact_cache_verification.json',report);print(json.dumps(report),flush=True)
if __name__=='__main__':main()
