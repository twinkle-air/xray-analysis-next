"""Conservative positive-quantification fusion; anchor decisions cannot change."""
import argparse,hashlib,json,pathlib
import numpy as np
import runtime_v2 as base
from spectral_fit import load,fit_one
from robust import quality_features,apply_quality
HERE=pathlib.Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def model(name):
 with np.load(HERE/name,allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}
def quality_guard(counts,f):
 rules=json.loads((HERE/'quality_rules.json').read_text(encoding='utf-8'))['rules'];strata=np.array(['round3/'+str(int(r)) for r in f['regime']]);_,distance,unknown=apply_quality(quality_features(counts,f),strata,rules)
 if unknown:raise ValueError('Unrepresented quality regime')
 return distance<=8,distance

def candidate_points(counts,f,previous):
 m2=model('baseline_model.npz');m3=model('model.npz');anchor,raw2,prob2,support2,null2=base.infer_cached(m2,counts,f,previous);point3=base.infer_cached(m3,counts,f,previous)[0];_,p2=base.quantification(m2,counts,f);_,p3=base.quantification(m3,counts,f)
 candidates=np.concatenate([point3[None,:,:],p2,p3]);ok,distance=quality_guard(counts,f)
 return anchor,candidates,ok,{'raw':raw2,'probability':prob2,'supported':support2,'null_threshold':null2,'quality_z':distance,'v3_point':point3}

def blend_column(anchor,candidate,alpha,mode,supported,quality_ok):
 anchor=np.asarray(anchor,dtype=float);candidate=np.asarray(candidate,dtype=float)
 if not 0<=alpha<=1 or mode not in [0,1]:raise ValueError('Invalid fusion rule')
 if alpha==0:return anchor.copy(),np.zeros(anchor.shape,dtype=bool)
 safe=supported&quality_ok&np.isfinite(candidate)&(anchor>0)&(candidate>0)&((anchor>=.001)==(candidate>=.001))
 value=anchor.copy()
 if mode==0:value[safe]=(1-alpha)*anchor[safe]+alpha*candidate[safe]
 else:value[safe]=np.exp((1-alpha)*np.log(anchor[safe])+alpha*np.log(candidate[safe]))
 # Numerical threshold boundary safety uses fallback, never artificial clipping.
 valid=np.isfinite(value)&((value>=.001)==(anchor>=.001));value[~valid]=anchor[~valid]
 assert np.array_equal(value>=.001,anchor>=.001) and np.all(value>=0)
 return value,value!=anchor

def infer_cached(fusion,counts,f,previous):
 anchor,candidates,quality_ok,audit=candidate_points(counts,f,previous);output=anchor.copy();changed=np.zeros_like(anchor,dtype=bool)
 for j in range(32):output[:,j],changed[:,j]=blend_column(anchor[:,j],candidates[int(fusion['candidate'][j]),:,j],float(fusion['alpha'][j]),int(fusion['mode'][j]),audit['supported'][:,j],quality_ok)
 return output,anchor,changed,audit

def predict(path):
 freeze=json.loads((HERE/'selection_freeze.json').read_text(encoding='utf-8'))
 for n,digest in freeze['runtime_sha256'].items():
  if sha(HERE/n)!=digest:raise ValueError('Frozen runtime changed: '+n)
 c=base.blind_counts(json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig')));d=load();r=fit_one(c,d);f={k:np.array([v]) for k,v in r.items()};previous=base.previous_prediction(c);fusion=model('fusion_model.npz');values,anchor,changed,audit=infer_cached(fusion,c[None,:],f,previous)
 return {'version':'v4-guarded-v2-v3-fusion','scope':'synthetic_numerical_research','formal_report_eligible':False,'hardware_validated':False,'predicted_element_percent':dict(zip(fusion['elements'].tolist(),values[0].tolist())),'v2_anchor_percent':dict(zip(fusion['elements'].tolist(),anchor[0].tolist())),'reported_percent':dict.fromkeys(fusion['elements'].tolist()),'fused_elements':[str(e) for e,b in zip(fusion['elements'],changed[0]) if b],'quality_reference':'frozen round3 training-only median/MAD','quality_max_robust_z':float(audit['quality_z'][0]),'quality_fallback_to_v2':bool(audit['quality_z'][0]>8),'ten_ppm_classification_matches_v2':bool(np.array_equal(values[0]>=.001,anchor[0]>=.001)),'element_evidence':{str(e):{'status':'conditional_signal_supported' if audit['supported'][0,j] else 'insufficient_spectral_evidence','conditional_SNR':float(r['snr'][j]),'omitted_element_deviance_improvement':float(r['null_delta'][j]),'zero_is_confirmed_absence':False} for j,e in enumerate(fusion['elements'])},'note':'Fusion changes positive quantification only under agreement. V2 false-positive and false-negative decisions at 10ppm are preserved, not independently improved. Research point estimates do not establish formal reporting or real-instrument accuracy.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--input',required=True,type=pathlib.Path);p.add_argument('--out',required=True,type=pathlib.Path);a=p.parse_args()
 if a.out.exists():raise FileExistsError(a.out)
 answer=predict(a.input)
 with a.out.open('x',encoding='utf-8') as out:json.dump(answer,out,ensure_ascii=False,indent=2,allow_nan=False)
