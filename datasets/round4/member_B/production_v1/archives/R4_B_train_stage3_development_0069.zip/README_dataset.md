# FP 合成数据集交付说明

生成器 0.2.2；物理模型 0.2.0。谱数 100，成分族 5。
生成完成不等于独立验收通过；本包状态为 pending_independent_validation。
全部为合成数据，未验证真实设备校准、检出限或真实盲测95%/5%准确度。

## 来源与复现
Each input row may carry a complete profile_override for one frozen condition. Two replicates of that row share the identical response and use different child seeds. configs/profile.json is only the fallback for rows without profile_override. Authoritative family/usage/stage assignments are external to the native batch split.
inputs/samples.json 是本批采用的完整输入；original_* 为CLI提供的原文件副本（如有）。
configs/profile.json、configs/jitter.json 是实际配置；reproducibility/recipe.json 是重建配方。
reproducibility/generator/fp_competition/ 是本批源码快照，含QC和重算工具。
reproducibility/requirements-lock.txt 是实际安装依赖；environment.json 记录Python和平台。
源码快照的core.py哈希记录在manifest。physics_baseline.json用于核实工作区基线的物理模块未变；
它不是此前缺源码的队友交付包的来源认证。

## 随机种子
批次seed=5825529653971479288：影响响应扰动与不同子种子的派生；每条谱使用自己记录的子种子抽计数。
有效split_seed=2026102501；未单独指定时沿用批次seed，因此改变批次seed也会影响划分。
配方设计种子在原始design文件中记录，独立于批次命令。仅在配方和响应固定时，改变单谱seed才只改变Poisson抽样。
同成分的重复谱不会跨集合；这不隔离未见设备、基体、近邻配方或不同批次合并后的泄漏。

## 能窗与损失
每条full和truth记录energy_window：通道中心 E_i=zero+gain*i；窗口边界为首中心-gain/2和末中心+gain/2。
整批窗口统计（keV）：{"unit": "keV", "first_center_range": [0.3, 0.6373928571428573], "last_center_range": [16.610495999999998, 29.333996188696723], "lower_edge_range": [0.296, 0.6304455357142859], "upper_edge_range": [16.614479999999997, 29.341024137138444]}。
源网格延伸到管压；荧光和散射均通过响应deposit；outside_window_counts记录响应卷积后窗外份额，
包括整条中心位于窗外的线或散射能量点及高斯尾部，不只记录峰尾。校验式：
detected_signal_before_window_counts ≈ sum(expected_counts-background) + sum(outside_window_counts)。
这里是效率/出射空气衰减后、截窗前的信号账目，不是源端光子守恒或仪器准确度证明。
损失比例仅按manifest中的明确定义统计：{"definition": "sum(outside_window_counts) / detected_signal_before_window_counts, excludes artificial background", "range": [0.0022323436909792663, 0.010415838287621618]}。
Ba统计：{"present": 100, "L_center_in_window": 100, "M_center_in_window": 100}。K线中心在窗外不意味着不能利用L/M线；
窗内线是否可定量还需单独评价响应、重叠、信噪与独立验证。

## 哈希与检查
每条record的blind_input_sha256（兼容别名sha256）对应盲输入，full_results_sha256对应完整结果。
integrity.json覆盖所有封存文件，包括truth、输入、配置、源码及manifest；自身排除以避免循环。
生成后不要向封存目录添加或改写文件；QC和重算报告写到包外。修改后须新建修订版、重建校验清单。
包内源码安装依赖后，从任意位置以其app.py运行：
python <包内app.py> audit --dataset <数据集目录> --out <包外qc.json>
python <包内app.py> replay --dataset <数据集目录> --out <包外replay.json>
replay默认重算全部；--limit仅抽查，不能写成全部完整重生成。对浮点使用rtol=1e-12、atol=1e-08 counts；
同环境计数要求逐道一致。环境差异和文件字节差异单独报告，不替代数值比较。
