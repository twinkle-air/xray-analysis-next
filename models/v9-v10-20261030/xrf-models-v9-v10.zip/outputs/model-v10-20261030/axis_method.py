"""Blind affine peak-pattern hypotheses; score/ambiguity is not calibrated probability."""
import numpy as np
import xraylib as xl
from scipy.signal import find_peaks
from scipy.optimize import nnls

def safe_irls(a,y,iterations=2):
    # Shifted-out columns carry no usable support. Solve only nonzero columns;
    # normalize them before NNLS to avoid subnormal scaling and coefficient overflow.
    support=a.sum(0)>1e-12;coef=np.zeros(a.shape[1]);mu=np.maximum(y,1.)
    if not support.any():return coef
    aa=a[:,support]
    for _ in range(iterations):
        weight=1/np.sqrt(np.maximum(mu,1));aw=aa*weight[:,None];scale=np.linalg.norm(aw,axis=0);valid=scale>1e-12
        cc=np.zeros(aa.shape[1])
        if valid.any():cc[valid]=nnls(aw[:,valid]/scale[valid],y*weight,maxiter=5000)[0]/scale[valid]
        coef[support]=cc;mu=a@coef
    assert np.isfinite(coef).all()
    return coef
def dictionary():
    symbols=['Na','Mg','Al','Si','P','S','Cl','K','Ca','Ti','V','Cr','Mn','Fe','Co','Ni','Cu','Zn','As','Se','Rb','Sr','Y','Zr','Nb','Mo','Cd','Sn','Sb','Ba','W','Pb','Ag'];lines=[];groups=[]
    for symbol in symbols:
        for family,names in [('K',('KA1_LINE','KB1_LINE')),('L',('LA1_LINE','LB1_LINE','LG1_LINE'))]:
            energies=[]
            for name in names:
                try:e=float(xl.LineEnergy(xl.SymbolToAtomicNumber(symbol),getattr(xl,name)))
                except ValueError:continue
                if 1<=e<=26:lines.append(e);energies.append(e)
            if len(energies)>=2:groups.append((symbol,family,np.array(energies)))
    return np.array(sorted(set(lines))),groups
def proposals(counts,old_gain,old_zero):
    c=np.asarray(counts,float);sm=np.convolve(c,[.25,.5,.25],mode='same');pk,properties=find_peaks(sm,prominence=max(8,4*np.sqrt(max(np.median(sm),1))),distance=6);order=np.argsort(properties['prominences'])[::-1][:12];pk=pk[order];prom=properties['prominences'][order]
    # Centroid around local maxima; no energy/profile/composition is accepted.
    centers=[]
    for k in pk:
        lo=max(0,k-3);hi=min(len(c),k+4);v=np.maximum(c[lo:hi]-min(c[lo],c[hi-1]),0);centers.append(float(np.dot(np.arange(lo,hi),v)/v.sum()) if v.sum()>0 else float(k))
    centers=np.array(centers);weights=np.sqrt(prom);weights=np.minimum(weights,3*np.median(weights));weights/=max(weights.sum(),1);energies,groups=dictionary();a,b=np.triu_indices(len(energies),1);e1=energies[a];e2=energies[b];keep=e2-e1>=.4;e1=e1[keep];e2=e2[keep];candidates=[]
    for i in range(min(8,len(centers))):
        for j in range(i+1,min(8,len(centers))):
            x1,x2=sorted((centers[i],centers[j]));delta=x2-x1
            if delta<20:continue
            gain=(e2-e1)/delta;zero=e1-gain*x1;valid=(gain>=.006)&(gain<=.020)&(zero>=-.25)&(zero<=1.25)
            candidates.extend((gg,zz,i,j) for gg,zz in zip(gain[valid].tolist(),zero[valid].tolist()))
    candidates.append((float(old_gain),float(old_zero),-1,-1));candidates=np.array(candidates)
    if len(centers)<4:return dict(peaks=centers.tolist(),candidates=[],reason='fewer_than4prominent_peaks')
    keys=np.c_[np.round(candidates[:,0]/.00002),np.round(candidates[:,1]/.01)];_,unique=np.unique(keys,axis=0,return_index=True);candidates=candidates[np.sort(unique)];ee=candidates[:,0,None]*centers+candidates[:,1,None];indices=np.searchsorted(energies,ee);left=np.clip(indices-1,0,len(energies)-1);right=np.clip(indices,0,len(energies)-1);dist=np.minimum(abs(ee-energies[left]),abs(ee-energies[right]));tol=.04+.002*np.maximum(ee,0);coverage=(np.exp(-.5*(dist/tol)**2)*weights).sum(1);match=dist<tol;kg=np.zeros(len(candidates));lg=kg.copy()
    for symbol,family,line in groups:
        delta=abs(ee[:,:,None]-line[None,None,:]);found=(delta<(.04+.002*line)[None,None,:]).any(axis=1);complete=found.all(1)
        if family=='K':kg+=complete
        else:lg+=complete
    remaining=np.broadcast_to(weights,(len(candidates),len(weights))).copy()
    for column in (2,3):
        valid=candidates[:,column]>=0;remaining[np.flatnonzero(valid),candidates[valid,column].astype(int)]=0
    holdout_coverage=(np.exp(-.5*(dist/tol)**2)*remaining).sum(1)/np.maximum(remaining.sum(1),1e-12)
    score=holdout_coverage+.07*np.minimum(kg,3)+.03*np.minimum(lg,3);ranking=np.argsort(score)[::-1];out=[]
    for k in ranking:
        gain,zero=candidates[k,:2]
        if any(max(abs((gain-r['gain'])*ch+zero-r['zero']) for ch in (100,1000,1800))<.06 for r in out):continue
        out.append(dict(gain=float(gain),zero=float(zero),score=float(score[k]),coverage=float(coverage[k]),nonseed_coverage=float(holdout_coverage[k]),seed_peak_indices=candidates[k,2:].astype(int).tolist(),matched_peaks=int(match[k].sum()),K_groups=int(kg[k]),L_groups=int(lg[k]),matched_span=float(np.ptp(ee[k,match[k]])) if match[k].sum()>1 else 0.))
        if len(out)==5:break
    return dict(peaks=centers.tolist(),prominences=prom.tolist(),enumerated=len(candidates),candidates=out,reason='fixed_peak_pattern_ranking')
def forced_fit(counts,d,spectral,gain,zero):
    y=np.asarray(counts,float).reshape(1024,2).sum(1);best=None
    for h in d['roots']:
        p=d['profiles'][h];theta=np.array([(gain/p['gain_keV_channel']-1)/.01,(zero-p['zero_keV'])/.05,0.]);A=spectral.warped(d[f'design_{h}'],theta,p['gain_keV_channel']);A[:,A.sum(0)<=1e-12]=0;co=safe_irls(A,y,iterations=2);mu=A@co;cost=spectral.deviance(y,mu)
        if best is None or cost<best['score']:best=dict(score=cost,h=h,theta=theta,A=A,co=co)
    h=best['h'];A=best['A'];co=best['co'];owners=d[f'owners_{h}'];mu=A@co;w=1/np.sqrt(np.maximum(mu,1));aw=A*w[:,None];scale=np.maximum(np.linalg.norm(aw,axis=0),1e-12);cov=np.linalg.pinv((aw/scale).T@(aw/scale),rcond=1e-12)/np.outer(scale,scale);merge=np.array([owners==j for j in range(32)],float);amp=merge@co;err=np.sqrt(np.maximum(np.diag(merge@cov@merge.T),1e-12));delta=np.zeros(32);shell=np.zeros((32,3));groups=d[f'groups_{h}']
    for j in range(32):
        selected=owners==j
        for k,s in enumerate('KLM'):shell[j,k]=sum(co[i] for i,g in enumerate(groups) if owners[i]==j and str(g).endswith('_'+s))
        if selected.any() and amp[j]>1e-12:
            null=safe_irls(A[:,~selected],y,iterations=2);delta[j]=spectral.deviance(y,A[:,~selected]@null)-best['score']
    p=d['profiles'][h];f=dict(amplitudes=amp,errors=err,snr=amp/err,null_delta=delta,shell=shell,hypothesis=h,continuum_fraction=float(co[owners<0].sum()/max(y.sum(),1)),deviance=best['score'],initial_deviance=best['score'],gain_keV_channel=gain,zero_keV=zero,noise_fwhm_eV=p['noise_fwhm_eV'],geometry_theta=best['theta'],geometry_converged=True,geometry_accepted=False,geometry_nfev=0,regime=int(gain<.01))
    return f
