"""Count-only nonlinear calibration; NumPy tree inference has no sklearn dependency."""
import argparse,json,pathlib
import numpy as np
import runtime_v4 as anchor_runtime
from spectral_fit import load,fit_one
HERE=pathlib.Path(__file__).resolve().parent
sha=anchor_runtime.sha

def shared_features(counts,f):
 counts=np.atleast_2d(counts);total=counts.sum(axis=1)
 return np.c_[anchor_runtime.base.matrix_features(counts,f),np.sqrt(np.maximum(f['amplitudes'],0)/total[:,None]),np.arcsinh(f['snr']),np.sqrt((counts.reshape(len(counts),128,16).sum(axis=2)+.375)/(total[:,None]+.375*128)),f['geometry_theta'],np.log1p(f['deviance']/1024)]

def element_features(shared,counts,f,j):
 total=np.atleast_2d(counts).sum(axis=1);shell=f['shell'][:,j];return np.c_[shared,np.log1p(f['amplitudes'][:,j]),np.log1p(f['errors'][:,j]),shell/np.maximum(shell.sum(axis=1,keepdims=True),1e-12),np.log(np.maximum(f['amplitudes'][:,j]/total,1e-20))]

def tree_prediction(nodes,x):
 at=np.zeros(len(x),dtype=np.int64)
 for _ in range(100):
  active=nodes['is_leaf'][at]==0
  if not active.any():return nodes['value'][at]
  ii=np.flatnonzero(active);current=nodes[at[ii]];value=x[ii,current['feature_idx'].astype(int)];left=np.where(np.isnan(value),current['missing_go_to_left'].astype(bool),value<=current['num_threshold']);at[ii]=np.where(left,current['left'],current['right'])
 raise ValueError('Invalid or cyclic tree')

def head_prediction(weights,k,j,x):
 prefix=f'h{k}_e{j}_';out=np.full(len(x),float(weights[prefix+'baseline'][0]));offset=weights[prefix+'offsets'];nodes=weights[prefix+'nodes']
 for a,b in zip(offset[:-1],offset[1:]):out+=tree_prediction(nodes[int(a):int(b)],x)
 return out

def nonlinear_candidates(weights,counts,f):
 shared=shared_features(counts,f);total=np.atleast_2d(counts).sum(axis=1);out=np.zeros((3,len(total),32))
 for j in range(32):
  x=element_features(shared,counts,f,j)
  for k in range(3):
   value=head_prediction(weights,k,j,x)
   if k<2:value=np.maximum(f['amplitudes'][:,j],0)/total*np.exp(np.clip(value,weights['low'][k,j],weights['high'][k,j]))
   out[k,:,j]=np.clip(value,0,100)
 return out

def guarded_blend(anchor,candidate,alpha,quality_z):
 if not 0<=alpha<=1:raise ValueError('Invalid alpha')
 safe=(anchor>0)&(candidate>0)&np.isfinite(candidate)&((anchor>=.001)==(candidate>=.001));ratio=np.divide(candidate,anchor,out=np.zeros_like(candidate),where=anchor>0);safe&=(ratio>=.25)&(ratio<=4)
 influence=np.minimum(1,8/np.maximum(quality_z,8));out=anchor.copy();a=alpha*influence[safe];out[safe]=(1-a)*anchor[safe]+a*candidate[safe]
 invalid=~np.isfinite(out)|((out>=.001)!=(anchor>=.001));out[invalid]=anchor[invalid]
 assert np.array_equal(out>=.001,anchor>=.001) and np.all(out[anchor==0]==0)
 return out,out!=anchor

def infer_cached(selection,weights,counts,f,previous):
 anchor,_,_,audit=anchor_runtime.infer_cached(anchor_runtime.model('fusion_model.npz'),counts,f,previous);candidates=nonlinear_candidates(weights,counts,f);output=anchor.copy();changed=np.zeros_like(anchor,dtype=bool)
 for j in range(32):output[:,j],changed[:,j]=guarded_blend(anchor[:,j],candidates[int(selection['head'][j]),:,j],float(selection['alpha'][j]),audit['quality_z'])
 return output,anchor,changed,audit

def predict(path):
 freeze=json.loads((HERE/'selection_freeze.json').read_text(encoding='utf-8'))
 for name,digest in freeze['runtime_sha256'].items():
  if sha(HERE/name)!=digest:raise ValueError('Frozen runtime changed: '+name)
 c=anchor_runtime.base.blind_counts(json.loads(pathlib.Path(path).read_text(encoding='utf-8-sig')));r=fit_one(c,load());f={k:np.array([v]) for k,v in r.items()};previous=anchor_runtime.base.previous_prediction(c)
 with np.load(HERE/'nonlinear_weights.npz',allow_pickle=False) as z:weights={k:z[k] for k in z.files}
 selection=anchor_runtime.model('selection_model.npz');point,old,changed,audit=infer_cached(selection,weights,c[None,:],f,previous)
 return {'version':'v5-nonlinear-matrix-correction','scope':'synthetic_numerical_research','formal_report_eligible':False,'hardware_validated':False,'predicted_element_percent':dict(zip(selection['elements'].tolist(),point[0].tolist())),'v4_anchor_percent':dict(zip(selection['elements'].tolist(),old[0].tolist())),'reported_percent':dict.fromkeys(selection['elements'].tolist()),'corrected_elements':[str(e) for e,b in zip(selection['elements'],changed[0]) if b],'ten_ppm_decisions_match_v4':bool(np.array_equal(point[0]>=.001,old[0]>=.001)),'quality_max_robust_z':float(audit['quality_z'][0]),'quality_correction_influence':float(min(1,8/max(float(audit['quality_z'][0]),8))),'element_evidence':{str(e):{'status':'conditional_signal_supported' if audit['supported'][0,j] else 'insufficient_spectral_evidence','conditional_SNR':float(r['snr'][j]),'zero_is_confirmed_absence':False} for j,e in enumerate(selection['elements'])},'note':'Positive nonlinear calibration preserves V4 detection decisions. Unsupported zeros remain in all accuracy denominators. This cannot repair V4 missed detections or establish real-device accuracy.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--input',required=True,type=pathlib.Path);p.add_argument('--out',required=True,type=pathlib.Path);a=p.parse_args()
 if a.out.exists():raise FileExistsError(a.out)
 answer=predict(a.input)
 with a.out.open('x',encoding='utf-8') as out:json.dump(answer,out,ensure_ascii=False,indent=2,allow_nan=False)
